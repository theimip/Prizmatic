-- MySQL dump 10.13  Distrib 5.5.28, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: prizmatic
-- ------------------------------------------------------
-- Server version	5.5.28-0ubuntu0.12.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounts_account`
--

DROP TABLE IF EXISTS `accounts_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounts_account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) DEFAULT NULL,
  `description` longtext,
  `account_type_id` int(11) DEFAULT NULL,
  `code` varchar(128) DEFAULT NULL,
  `primary_user_id` int(11) DEFAULT NULL,
  `status` varchar(32) NOT NULL,
  `credit_limit` decimal(12,2) DEFAULT NULL,
  `balance` decimal(12,2) DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `product_range_id` int(11) DEFAULT NULL,
  `can_be_used_for_non_products` tinyint(1) NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`),
  KEY `accounts_account_1cb8f5b0` (`account_type_id`),
  KEY `accounts_account_8d3b64d8` (`primary_user_id`),
  KEY `accounts_account_d4b14d36` (`product_range_id`),
  CONSTRAINT `account_type_id_refs_id_28bf1a446d19ccbf` FOREIGN KEY (`account_type_id`) REFERENCES `accounts_accounttype` (`id`),
  CONSTRAINT `primary_user_id_refs_id_654b320f0712b888` FOREIGN KEY (`primary_user_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `product_range_id_refs_id_6b2f054f813892e2` FOREIGN KEY (`product_range_id`) REFERENCES `offer_range` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts_account`
--

LOCK TABLES `accounts_account` WRITE;
/*!40000 ALTER TABLE `accounts_account` DISABLE KEYS */;
INSERT INTO `accounts_account` VALUES (1,'Sales Account',NULL,2,NULL,NULL,'Open',0.00,0.00,NULL,NULL,NULL,1,'2013-05-08 14:24:32'),(2,'Expired Account',NULL,2,NULL,NULL,'Open',0.00,0.00,NULL,NULL,NULL,1,'2013-05-08 14:24:32'),(3,'Bank',NULL,3,NULL,NULL,'Open',NULL,0.00,NULL,NULL,NULL,1,'2013-05-08 14:24:32'),(4,'Unpaid source',NULL,4,NULL,NULL,'Open',NULL,-1030.00,NULL,NULL,NULL,1,'2013-05-08 14:24:32'),(5,'The Main Account','',7,'ADHMXFKDKRHT',NULL,'Open',0.00,1000.00,NULL,NULL,NULL,1,'2013-05-10 11:21:19'),(6,'Trade Account','New trade account opened or dave',7,'MMES8Z2DDEDT',NULL,'Open',0.00,30.00,NULL,NULL,NULL,1,'2013-05-10 13:20:01');
/*!40000 ALTER TABLE `accounts_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounts_account_secondary_users`
--

DROP TABLE IF EXISTS `accounts_account_secondary_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounts_account_secondary_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `accounts_account_secondary_use_account_id_46b7ed0aad009f6b_uniq` (`account_id`,`user_id`),
  KEY `accounts_account_secondary_users_6f2fe10e` (`account_id`),
  KEY `accounts_account_secondary_users_fbfc09f1` (`user_id`),
  CONSTRAINT `account_id_refs_id_998ed0eb43e158d` FOREIGN KEY (`account_id`) REFERENCES `accounts_account` (`id`),
  CONSTRAINT `user_id_refs_id_4c7d44013e031f42` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts_account_secondary_users`
--

LOCK TABLES `accounts_account_secondary_users` WRITE;
/*!40000 ALTER TABLE `accounts_account_secondary_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounts_account_secondary_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounts_accounttype`
--

DROP TABLE IF EXISTS `accounts_accounttype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounts_accounttype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `path` varchar(255) NOT NULL,
  `depth` int(10) unsigned NOT NULL,
  `numchild` int(10) unsigned NOT NULL,
  `code` varchar(128) DEFAULT NULL,
  `name` varchar(128) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `path` (`path`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts_accounttype`
--

LOCK TABLES `accounts_accounttype` WRITE;
/*!40000 ALTER TABLE `accounts_accounttype` DISABLE KEYS */;
INSERT INTO `accounts_accounttype` VALUES (1,'0001',1,3,NULL,'Assets'),(2,'00010001',2,0,NULL,'Sales'),(3,'00010002',2,0,NULL,'Cash'),(4,'00010003',2,0,NULL,'Unpaid accounts'),(5,'0002',1,1,NULL,'Liabilities'),(6,'00020001',2,1,NULL,'Deferred income'),(7,'000200010001',3,0,NULL,'Dashboard created accounts');
/*!40000 ALTER TABLE `accounts_accounttype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounts_ipaddressrecord`
--

DROP TABLE IF EXISTS `accounts_ipaddressrecord`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounts_ipaddressrecord` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_address` char(15) NOT NULL,
  `total_failures` int(10) unsigned NOT NULL,
  `consecutive_failures` int(10) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `date_last_failure` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip_address` (`ip_address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts_ipaddressrecord`
--

LOCK TABLES `accounts_ipaddressrecord` WRITE;
/*!40000 ALTER TABLE `accounts_ipaddressrecord` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounts_ipaddressrecord` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounts_transaction`
--

DROP TABLE IF EXISTS `accounts_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounts_transaction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transfer_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `accounts_transaction_transfer_id_740ade80e73f985a_uniq` (`transfer_id`,`account_id`),
  KEY `accounts_transaction_b7d24dfb` (`transfer_id`),
  KEY `accounts_transaction_6f2fe10e` (`account_id`),
  CONSTRAINT `account_id_refs_id_28273839846ba6c6` FOREIGN KEY (`account_id`) REFERENCES `accounts_account` (`id`),
  CONSTRAINT `transfer_id_refs_id_5dfce76ee9de8009` FOREIGN KEY (`transfer_id`) REFERENCES `accounts_transfer` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts_transaction`
--

LOCK TABLES `accounts_transaction` WRITE;
/*!40000 ALTER TABLE `accounts_transaction` DISABLE KEYS */;
INSERT INTO `accounts_transaction` VALUES (1,1,4,-1000.00,'2013-05-10 11:21:19'),(2,1,5,1000.00,'2013-05-10 11:21:19'),(3,2,4,-30.00,'2013-05-10 13:20:01'),(4,2,6,30.00,'2013-05-10 13:20:01');
/*!40000 ALTER TABLE `accounts_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounts_transfer`
--

DROP TABLE IF EXISTS `accounts_transfer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounts_transfer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` varchar(64) DEFAULT NULL,
  `source_id` int(11) NOT NULL,
  `destination_id` int(11) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `merchant_reference` varchar(128) DEFAULT NULL,
  `description` varchar(256) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `username` varchar(128) NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `reference` (`reference`),
  KEY `accounts_transfer_89f89e85` (`source_id`),
  KEY `accounts_transfer_90a09905` (`destination_id`),
  KEY `accounts_transfer_63f17a16` (`parent_id`),
  KEY `accounts_transfer_fbfc09f1` (`user_id`),
  CONSTRAINT `destination_id_refs_id_2105b00603269e1c` FOREIGN KEY (`destination_id`) REFERENCES `accounts_account` (`id`),
  CONSTRAINT `parent_id_refs_id_5f110861f698aaed` FOREIGN KEY (`parent_id`) REFERENCES `accounts_transfer` (`id`),
  CONSTRAINT `source_id_refs_id_2105b00603269e1c` FOREIGN KEY (`source_id`) REFERENCES `accounts_account` (`id`),
  CONSTRAINT `user_id_refs_id_6a60e505841e825f` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts_transfer`
--

LOCK TABLES `accounts_transfer` WRITE;
/*!40000 ALTER TABLE `accounts_transfer` DISABLE KEYS */;
INSERT INTO `accounts_transfer` VALUES (1,'92F71D0E08CEC936DD0DC0B0B722AD41',4,5,1000.00,NULL,NULL,'Creation of account',1,'admin@theimip.com','2013-05-10 11:21:19'),(2,'F2F58300283467696A40DD507B4BA22D',4,6,30.00,NULL,NULL,'Creation of account',1,'admin@theimip.com','2013-05-10 13:20:01');
/*!40000 ALTER TABLE `accounts_transfer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `address_country`
--

DROP TABLE IF EXISTS `address_country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `address_country` (
  `iso_3166_1_a2` varchar(2) NOT NULL,
  `iso_3166_1_a3` varchar(3) DEFAULT NULL,
  `iso_3166_1_numeric` smallint(5) unsigned DEFAULT NULL,
  `name` varchar(128) NOT NULL,
  `printable_name` varchar(128) NOT NULL,
  `is_highlighted` tinyint(1) NOT NULL,
  `is_shipping_country` tinyint(1) NOT NULL,
  PRIMARY KEY (`iso_3166_1_a2`),
  KEY `address_country_5c8e0e7d` (`iso_3166_1_a3`),
  KEY `address_country_73b0508d` (`iso_3166_1_numeric`),
  KEY `address_country_ce990a17` (`is_highlighted`),
  KEY `address_country_b029f1ea` (`is_shipping_country`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `address_country`
--

LOCK TABLES `address_country` WRITE;
/*!40000 ALTER TABLE `address_country` DISABLE KEYS */;
/*!40000 ALTER TABLE `address_country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `address_useraddress`
--

DROP TABLE IF EXISTS `address_useraddress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `address_useraddress` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(64) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) NOT NULL,
  `line1` varchar(255) NOT NULL,
  `line2` varchar(255) DEFAULT NULL,
  `line3` varchar(255) DEFAULT NULL,
  `line4` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `postcode` varchar(64),
  `country_id` varchar(2) NOT NULL,
  `search_text` varchar(1000) NOT NULL,
  `phone_number` varchar(32) DEFAULT NULL,
  `notes` longtext,
  `user_id` int(11) NOT NULL,
  `is_default_for_shipping` tinyint(1) NOT NULL,
  `is_default_for_billing` tinyint(1) NOT NULL,
  `num_orders` int(10) unsigned NOT NULL,
  `hash` varchar(255) NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `address_useraddress_534dd89` (`country_id`),
  KEY `address_useraddress_fbfc09f1` (`user_id`),
  KEY `address_useraddress_36af87d1` (`hash`),
  CONSTRAINT `country_id_refs_iso_3166_1_a2_ae61609ccc92d76` FOREIGN KEY (`country_id`) REFERENCES `address_country` (`iso_3166_1_a2`),
  CONSTRAINT `user_id_refs_id_47d5b6333bcad141` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `address_useraddress`
--

LOCK TABLES `address_useraddress` WRITE;
/*!40000 ALTER TABLE `address_useraddress` DISABLE KEYS */;
/*!40000 ALTER TABLE `address_useraddress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_tools_dashboard_preferences`
--

DROP TABLE IF EXISTS `admin_tools_dashboard_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_tools_dashboard_preferences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `data` longtext NOT NULL,
  `dashboard_id` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_tools_dashboard_prefer_dashboard_id_374bce90a8a4eefc_uniq` (`dashboard_id`,`user_id`),
  KEY `admin_tools_dashboard_preferences_fbfc09f1` (`user_id`),
  CONSTRAINT `user_id_refs_id_2faedda1f8487376` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_tools_dashboard_preferences`
--

LOCK TABLES `admin_tools_dashboard_preferences` WRITE;
/*!40000 ALTER TABLE `admin_tools_dashboard_preferences` DISABLE KEYS */;
INSERT INTO `admin_tools_dashboard_preferences` VALUES (1,1,'{}','dashboard'),(2,1,'{}','sites-dashboard'),(3,1,'{}','csvimport-dashboard'),(4,1,'{}','partner-dashboard'),(5,1,'{}','catalogue-dashboard'),(6,1,'{}','auth-dashboard'),(7,1,'{}','accounts-dashboard'),(8,4,'{}','catalogue-dashboard'),(9,4,'{}','gap-dashboard'),(10,4,'{}','dashboard');
/*!40000 ALTER TABLE `admin_tools_dashboard_preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_tools_menu_bookmark`
--

DROP TABLE IF EXISTS `admin_tools_menu_bookmark`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_tools_menu_bookmark` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `url` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `admin_tools_menu_bookmark_fbfc09f1` (`user_id`),
  CONSTRAINT `user_id_refs_id_6af2836063b2844f` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_tools_menu_bookmark`
--

LOCK TABLES `admin_tools_menu_bookmark` WRITE;
/*!40000 ALTER TABLE `admin_tools_menu_bookmark` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_tools_menu_bookmark` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `analytics_productrecord`
--

DROP TABLE IF EXISTS `analytics_productrecord`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `analytics_productrecord` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `num_views` int(10) unsigned NOT NULL,
  `num_basket_additions` int(10) unsigned NOT NULL,
  `num_purchases` int(10) unsigned NOT NULL,
  `score` double NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_id` (`product_id`),
  KEY `analytics_productrecord_f3d3e28f` (`num_purchases`),
  CONSTRAINT `product_id_refs_id_54539efdb53e5469` FOREIGN KEY (`product_id`) REFERENCES `catalogue_product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `analytics_productrecord`
--

LOCK TABLES `analytics_productrecord` WRITE;
/*!40000 ALTER TABLE `analytics_productrecord` DISABLE KEYS */;
INSERT INTO `analytics_productrecord` VALUES (1,1,229,0,0,0);
/*!40000 ALTER TABLE `analytics_productrecord` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `analytics_userproductview`
--

DROP TABLE IF EXISTS `analytics_userproductview`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `analytics_userproductview` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `analytics_userproductview_fbfc09f1` (`user_id`),
  KEY `analytics_userproductview_bb420c12` (`product_id`),
  CONSTRAINT `product_id_refs_id_79865e235e6ecec` FOREIGN KEY (`product_id`) REFERENCES `catalogue_product` (`id`),
  CONSTRAINT `user_id_refs_id_2d1d77bf2d5d69a9` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=178 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `analytics_userproductview`
--

LOCK TABLES `analytics_userproductview` WRITE;
/*!40000 ALTER TABLE `analytics_userproductview` DISABLE KEYS */;
INSERT INTO `analytics_userproductview` VALUES (1,1,1,'2013-05-11 07:57:42'),(2,1,1,'2013-05-11 07:57:46'),(3,1,1,'2013-05-11 07:58:54'),(4,1,1,'2013-05-11 07:58:56'),(5,1,1,'2013-05-11 07:59:01'),(6,1,1,'2013-05-11 07:59:04'),(7,1,1,'2013-05-11 07:59:28'),(8,1,1,'2013-05-11 07:59:30'),(9,1,1,'2013-05-11 07:59:53'),(10,1,1,'2013-05-11 08:00:07'),(11,1,1,'2013-05-11 08:04:51'),(12,1,1,'2013-05-11 08:04:57'),(13,1,1,'2013-05-11 08:06:04'),(14,1,1,'2013-05-11 08:06:49'),(15,1,1,'2013-05-11 08:06:57'),(16,1,1,'2013-05-11 08:06:59'),(17,1,1,'2013-05-11 08:07:05'),(18,1,1,'2013-05-11 08:07:43'),(19,1,1,'2013-05-11 08:07:45'),(20,1,1,'2013-05-11 08:08:06'),(21,1,1,'2013-05-11 08:09:37'),(22,1,1,'2013-05-11 08:10:31'),(23,1,1,'2013-05-11 08:12:17'),(24,1,1,'2013-05-11 08:14:28'),(25,1,1,'2013-05-11 08:14:33'),(26,1,1,'2013-05-11 08:14:35'),(27,1,1,'2013-05-11 08:15:54'),(28,1,1,'2013-05-11 08:17:10'),(29,1,1,'2013-05-11 08:17:17'),(30,1,1,'2013-05-11 08:18:56'),(31,1,1,'2013-05-11 08:20:09'),(32,1,1,'2013-05-11 08:20:13'),(33,1,1,'2013-05-11 08:21:04'),(34,1,1,'2013-05-11 08:21:08'),(35,1,1,'2013-05-11 08:21:12'),(36,1,1,'2013-05-11 08:21:53'),(37,1,1,'2013-05-11 08:24:07'),(38,1,1,'2013-05-11 08:30:48'),(39,1,1,'2013-05-11 08:32:50'),(40,1,1,'2013-05-11 08:37:03'),(41,1,1,'2013-05-11 08:37:06'),(42,1,1,'2013-05-11 08:37:11'),(43,1,1,'2013-05-11 08:37:40'),(44,1,1,'2013-05-11 08:43:14'),(45,1,1,'2013-05-11 08:45:31'),(46,1,1,'2013-05-11 08:45:49'),(47,1,1,'2013-05-11 08:50:17'),(48,1,1,'2013-05-11 08:50:20'),(49,1,1,'2013-05-11 08:51:28'),(50,1,1,'2013-05-11 08:51:43'),(51,1,1,'2013-05-11 08:51:58'),(52,1,1,'2013-05-11 08:52:27'),(53,1,1,'2013-05-11 08:53:42'),(54,1,1,'2013-05-11 08:55:09'),(55,1,1,'2013-05-11 11:33:51'),(56,1,1,'2013-05-11 11:36:08'),(57,1,1,'2013-05-11 11:37:59'),(58,1,1,'2013-05-11 11:38:01'),(59,1,1,'2013-05-11 11:38:19'),(60,1,1,'2013-05-11 11:39:58'),(61,1,1,'2013-05-11 11:40:33'),(62,1,1,'2013-05-11 11:41:11'),(63,1,1,'2013-05-11 11:41:13'),(64,1,1,'2013-05-11 11:42:21'),(65,1,1,'2013-05-11 11:42:39'),(66,1,1,'2013-05-11 11:42:44'),(67,1,1,'2013-05-11 11:45:39'),(68,1,1,'2013-05-11 11:45:48'),(69,1,1,'2013-05-11 11:46:29'),(70,1,1,'2013-05-11 11:47:18'),(71,1,1,'2013-05-11 11:47:21'),(72,1,1,'2013-05-11 13:54:57'),(73,1,1,'2013-05-11 13:54:59'),(74,1,1,'2013-05-11 13:56:48'),(75,1,1,'2013-05-11 13:56:49'),(76,1,1,'2013-05-11 14:01:22'),(77,1,1,'2013-05-11 14:01:23'),(78,1,1,'2013-05-11 17:14:37'),(79,1,1,'2013-05-11 17:14:38'),(80,1,1,'2013-05-11 17:15:43'),(81,1,1,'2013-05-11 17:15:44'),(82,1,1,'2013-05-11 19:12:44'),(83,1,1,'2013-05-11 19:12:46'),(84,1,1,'2013-05-12 13:07:47'),(85,1,1,'2013-05-12 13:07:49'),(86,1,1,'2013-05-12 13:35:09'),(87,1,1,'2013-05-12 16:03:31'),(88,1,1,'2013-05-12 20:32:00'),(89,1,1,'2013-05-12 20:32:01'),(90,1,1,'2013-05-12 20:57:50'),(91,1,1,'2013-05-12 20:57:51'),(92,1,1,'2013-05-12 21:06:10'),(93,1,1,'2013-05-12 21:06:40'),(94,1,1,'2013-05-12 21:06:41'),(95,1,1,'2013-05-12 21:07:35'),(96,1,1,'2013-05-13 07:27:05'),(97,1,1,'2013-05-13 07:27:06'),(98,1,1,'2013-05-13 09:43:36'),(99,1,1,'2013-05-13 09:43:37'),(100,1,1,'2013-05-13 10:47:43'),(101,1,1,'2013-05-13 10:47:44'),(102,1,1,'2013-05-13 12:36:49'),(103,1,1,'2013-05-13 12:36:49'),(104,1,1,'2013-05-13 12:39:10'),(105,1,1,'2013-05-13 12:39:11'),(106,1,1,'2013-05-13 14:47:42'),(107,1,1,'2013-05-13 14:47:43'),(108,1,1,'2013-05-13 17:50:56'),(109,1,1,'2013-05-13 17:50:58'),(110,1,1,'2013-05-14 06:40:25'),(111,1,1,'2013-05-14 06:40:26'),(112,1,1,'2013-05-14 07:12:04'),(113,1,1,'2013-05-14 07:12:05'),(114,1,1,'2013-05-14 13:38:10'),(115,1,1,'2013-05-14 13:38:11'),(116,1,1,'2013-05-14 14:07:23'),(117,1,1,'2013-05-14 14:07:24'),(118,1,1,'2013-05-14 14:33:09'),(119,1,1,'2013-05-14 14:33:09'),(120,1,1,'2013-05-14 17:57:44'),(121,1,1,'2013-05-14 17:57:45'),(122,1,1,'2013-05-14 20:14:38'),(123,1,1,'2013-05-14 20:14:40'),(124,1,1,'2013-05-16 09:25:10'),(125,1,1,'2013-05-16 13:20:17'),(126,1,1,'2013-05-16 13:20:17'),(127,1,1,'2013-05-16 15:08:57'),(128,1,1,'2013-05-17 10:40:54'),(129,1,1,'2013-05-17 10:40:56'),(130,1,1,'2013-05-18 07:42:12'),(131,1,1,'2013-05-18 07:42:13'),(132,1,1,'2013-05-18 19:26:44'),(133,1,1,'2013-05-18 19:26:45'),(134,1,1,'2013-05-19 19:19:21'),(135,1,1,'2013-05-19 19:27:31'),(136,1,1,'2013-05-19 19:27:32'),(137,1,1,'2013-05-19 19:29:36'),(138,1,1,'2013-05-19 19:31:12'),(139,1,1,'2013-05-19 19:31:54'),(140,1,1,'2013-05-19 19:33:14'),(141,1,1,'2013-05-19 19:33:16'),(142,1,1,'2013-05-19 19:38:16'),(143,1,1,'2013-05-20 07:17:50'),(144,1,1,'2013-05-20 07:17:52'),(145,4,1,'2013-05-20 18:17:31'),(146,4,1,'2013-05-20 18:39:11'),(147,4,1,'2013-05-20 18:44:17'),(148,4,1,'2013-05-20 18:44:18'),(149,4,1,'2013-05-20 19:21:39'),(150,4,1,'2013-05-20 19:21:40'),(151,4,1,'2013-05-20 21:08:26'),(152,4,1,'2013-05-20 21:08:27'),(153,1,1,'2013-05-20 23:05:39'),(154,4,1,'2013-05-21 07:20:40'),(155,4,1,'2013-05-21 08:09:19'),(156,4,1,'2013-05-21 08:09:20'),(157,4,1,'2013-05-21 09:29:38'),(158,4,1,'2013-05-21 09:29:40'),(159,4,1,'2013-05-21 11:47:07'),(160,4,1,'2013-05-21 11:47:07'),(161,4,1,'2013-05-21 11:48:13'),(162,4,1,'2013-05-21 11:48:13'),(163,1,1,'2013-05-21 12:28:42'),(164,4,1,'2013-05-21 13:02:00'),(165,4,1,'2013-05-21 13:02:01'),(166,4,1,'2013-05-21 17:26:23'),(167,4,1,'2013-05-21 17:26:25'),(168,4,1,'2013-05-21 17:36:51'),(169,4,1,'2013-05-21 17:36:52'),(170,4,1,'2013-05-21 19:14:24'),(171,4,1,'2013-05-21 19:14:24'),(172,4,1,'2013-05-21 19:53:16'),(173,4,1,'2013-05-21 19:53:17'),(174,4,1,'2013-05-22 07:34:41'),(175,4,1,'2013-05-22 07:34:42'),(176,4,1,'2013-05-22 07:54:45'),(177,4,1,'2013-05-22 07:54:47');
/*!40000 ALTER TABLE `analytics_userproductview` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `analytics_userrecord`
--

DROP TABLE IF EXISTS `analytics_userrecord`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `analytics_userrecord` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `num_product_views` int(10) unsigned NOT NULL,
  `num_basket_additions` int(10) unsigned NOT NULL,
  `num_orders` int(10) unsigned NOT NULL,
  `num_order_lines` int(10) unsigned NOT NULL,
  `num_order_items` int(10) unsigned NOT NULL,
  `total_spent` decimal(12,2) NOT NULL,
  `date_last_order` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `analytics_userrecord_d67315` (`num_orders`),
  KEY `analytics_userrecord_7698f02b` (`num_order_lines`),
  KEY `analytics_userrecord_1cbbd474` (`num_order_items`),
  CONSTRAINT `user_id_refs_id_4240573fc321bd93` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `analytics_userrecord`
--

LOCK TABLES `analytics_userrecord` WRITE;
/*!40000 ALTER TABLE `analytics_userrecord` DISABLE KEYS */;
INSERT INTO `analytics_userrecord` VALUES (1,1,146,0,0,0,0,0.00,NULL),(2,4,31,0,0,0,0,0.00,NULL);
/*!40000 ALTER TABLE `analytics_userrecord` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `analytics_usersearch`
--

DROP TABLE IF EXISTS `analytics_usersearch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `analytics_usersearch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `query` varchar(255) NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `analytics_usersearch_fbfc09f1` (`user_id`),
  KEY `analytics_usersearch_b8873da2` (`query`),
  CONSTRAINT `user_id_refs_id_500456b14f2d4d4e` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `analytics_usersearch`
--

LOCK TABLES `analytics_usersearch` WRITE;
/*!40000 ALTER TABLE `analytics_usersearch` DISABLE KEYS */;
/*!40000 ALTER TABLE `analytics_usersearch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_id` (`group_id`,`permission_id`),
  KEY `auth_group_permissions_bda51c3c` (`group_id`),
  KEY `auth_group_permissions_1e014c8f` (`permission_id`),
  CONSTRAINT `group_id_refs_id_3cea63fe` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `permission_id_refs_id_a7792de1` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_type_id` (`content_type_id`,`codename`),
  KEY `auth_permission_e4470c6e` (`content_type_id`),
  CONSTRAINT `content_type_id_refs_id_728de91f` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=323 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add permission',1,'add_permission'),(2,'Can change permission',1,'change_permission'),(3,'Can delete permission',1,'delete_permission'),(4,'Can add group',2,'add_group'),(5,'Can change group',2,'change_group'),(6,'Can delete group',2,'delete_group'),(7,'Can add user',3,'add_user'),(8,'Can change user',3,'change_user'),(9,'Can delete user',3,'delete_user'),(10,'Can add content type',4,'add_contenttype'),(11,'Can change content type',4,'change_contenttype'),(12,'Can delete content type',4,'delete_contenttype'),(13,'Can add session',5,'add_session'),(14,'Can change session',5,'change_session'),(15,'Can delete session',5,'delete_session'),(16,'Can add site',6,'add_site'),(17,'Can change site',6,'change_site'),(18,'Can delete site',6,'delete_site'),(19,'Can add flat page',7,'add_flatpage'),(20,'Can change flat page',7,'change_flatpage'),(21,'Can delete flat page',7,'delete_flatpage'),(22,'Can add log entry',8,'add_logentry'),(23,'Can change log entry',8,'change_logentry'),(24,'Can delete log entry',8,'delete_logentry'),(25,'Can add migration history',9,'add_migrationhistory'),(26,'Can change migration history',9,'change_migrationhistory'),(27,'Can delete migration history',9,'delete_migrationhistory'),(28,'Can add Product Review',10,'add_productreview'),(29,'Can change Product Review',10,'change_productreview'),(30,'Can delete Product Review',10,'delete_productreview'),(31,'Can add Vote',11,'add_vote'),(32,'Can change Vote',11,'change_vote'),(33,'Can delete Vote',11,'delete_vote'),(34,'Can add kv store',12,'add_kvstore'),(35,'Can change kv store',12,'change_kvstore'),(36,'Can delete kv store',12,'delete_kvstore'),(37,'Can add csv import',13,'add_csvimport'),(38,'Can change csv import',13,'change_csvimport'),(39,'Can delete csv import',13,'delete_csvimport'),(40,'Can add import model',14,'add_importmodel'),(41,'Can change import model',14,'change_importmodel'),(42,'Can delete import model',14,'delete_importmodel'),(43,'Can add bookmark',15,'add_bookmark'),(44,'Can change bookmark',15,'change_bookmark'),(45,'Can delete bookmark',15,'delete_bookmark'),(46,'Can add dashboard preferences',16,'add_dashboardpreferences'),(47,'Can change dashboard preferences',16,'change_dashboardpreferences'),(48,'Can delete dashboard preferences',16,'delete_dashboardpreferences'),(49,'Can add account type',17,'add_accounttype'),(50,'Can change account type',17,'change_accounttype'),(51,'Can delete account type',17,'delete_accounttype'),(52,'Can add account',18,'add_account'),(53,'Can change account',18,'change_account'),(54,'Can delete account',18,'delete_account'),(55,'Can add transfer',19,'add_transfer'),(56,'Can change transfer',19,'change_transfer'),(57,'Can delete transfer',19,'delete_transfer'),(58,'Can add transaction',20,'add_transaction'),(59,'Can change transaction',20,'change_transaction'),(60,'Can delete transaction',20,'delete_transaction'),(61,'Can add IP address record',21,'add_ipaddressrecord'),(62,'Can change IP address record',21,'change_ipaddressrecord'),(63,'Can delete IP address record',21,'delete_ipaddressrecord'),(64,'Can add Email',22,'add_email'),(65,'Can change Email',22,'change_email'),(66,'Can delete Email',22,'delete_email'),(67,'Can add Communication event type',23,'add_communicationeventtype'),(68,'Can change Communication event type',23,'change_communicationeventtype'),(69,'Can delete Communication event type',23,'delete_communicationeventtype'),(70,'Can add notification',24,'add_notification'),(71,'Can change notification',24,'change_notification'),(72,'Can delete notification',24,'delete_notification'),(73,'Can add product alert',25,'add_productalert'),(74,'Can change product alert',25,'change_productalert'),(75,'Can delete product alert',25,'delete_productalert'),(76,'Can add Product Recommendation',26,'add_productrecommendation'),(77,'Can change Product Recommendation',26,'change_productrecommendation'),(78,'Can delete Product Recommendation',26,'delete_productrecommendation'),(79,'Can add Product Class',27,'add_productclass'),(80,'Can change Product Class',27,'change_productclass'),(81,'Can delete Product Class',27,'delete_productclass'),(82,'Can add Category',28,'add_category'),(83,'Can change Category',28,'change_category'),(84,'Can delete Category',28,'delete_category'),(85,'Can add Product Category',29,'add_productcategory'),(86,'Can change Product Category',29,'change_productcategory'),(87,'Can delete Product Category',29,'delete_productcategory'),(88,'Can add Product',30,'add_product'),(89,'Can change Product',30,'change_product'),(90,'Can delete Product',30,'delete_product'),(91,'Can add Contributor Role',31,'add_contributorrole'),(92,'Can change Contributor Role',31,'change_contributorrole'),(93,'Can delete Contributor Role',31,'delete_contributorrole'),(94,'Can add Contributor',32,'add_contributor'),(95,'Can change Contributor',32,'change_contributor'),(96,'Can delete Contributor',32,'delete_contributor'),(97,'Can add Product Contributor',33,'add_productcontributor'),(98,'Can change Product Contributor',33,'change_productcontributor'),(99,'Can delete Product Contributor',33,'delete_productcontributor'),(100,'Can add Product Attribute',34,'add_productattribute'),(101,'Can change Product Attribute',34,'change_productattribute'),(102,'Can delete Product Attribute',34,'delete_productattribute'),(103,'Can add Product Attribute Value',35,'add_productattributevalue'),(104,'Can change Product Attribute Value',35,'change_productattributevalue'),(105,'Can delete Product Attribute Value',35,'delete_productattributevalue'),(106,'Can add Attribute Option Group',36,'add_attributeoptiongroup'),(107,'Can change Attribute Option Group',36,'change_attributeoptiongroup'),(108,'Can delete Attribute Option Group',36,'delete_attributeoptiongroup'),(109,'Can add Attribute Option',37,'add_attributeoption'),(110,'Can change Attribute Option',37,'change_attributeoption'),(111,'Can delete Attribute Option',37,'delete_attributeoption'),(112,'Can add Attribute Entity',38,'add_attributeentity'),(113,'Can change Attribute Entity',38,'change_attributeentity'),(114,'Can delete Attribute Entity',38,'delete_attributeentity'),(115,'Can add Attribute Entity Type',39,'add_attributeentitytype'),(116,'Can change Attribute Entity Type',39,'change_attributeentitytype'),(117,'Can delete Attribute Entity Type',39,'delete_attributeentitytype'),(118,'Can add Option',40,'add_option'),(119,'Can change Option',40,'change_option'),(120,'Can delete Option',40,'delete_option'),(121,'Can add Product Image',41,'add_productimage'),(122,'Can change Product Image',41,'change_productimage'),(123,'Can delete Product Image',41,'delete_productimage'),(124,'Can add Product record',42,'add_productrecord'),(125,'Can change Product record',42,'change_productrecord'),(126,'Can delete Product record',42,'delete_productrecord'),(127,'Can add User Record',43,'add_userrecord'),(128,'Can change User Record',43,'change_userrecord'),(129,'Can delete User Record',43,'delete_userrecord'),(130,'Can add Basket',44,'add_userproductview'),(131,'Can change Basket',44,'change_userproductview'),(132,'Can delete Basket',44,'delete_userproductview'),(133,'Can add user search',45,'add_usersearch'),(134,'Can change user search',45,'change_usersearch'),(135,'Can delete user search',45,'delete_usersearch'),(136,'Can add Fulfillment partner',46,'add_partner'),(137,'Can change Fulfillment partner',46,'change_partner'),(138,'Can delete Fulfillment partner',46,'delete_partner'),(139,'Can edit stock records',46,'can_edit_stock_records'),(140,'Can view stock records',46,'can_view_stock_records'),(141,'Can edit product range',46,'can_edit_product_range'),(142,'Can view product range',46,'can_view_product_range'),(143,'Can edit order lines',46,'can_edit_order_lines'),(144,'Can view order lines',46,'can_view_order_lines'),(145,'Can add Stock Record',47,'add_stockrecord'),(146,'Can change Stock Record',47,'change_stockrecord'),(147,'Can delete Stock Record',47,'delete_stockrecord'),(148,'Can add Stock Alert',48,'add_stockalert'),(149,'Can change Stock Alert',48,'change_stockalert'),(150,'Can delete Stock Alert',48,'delete_stockalert'),(151,'Can add User address',49,'add_useraddress'),(152,'Can change User address',49,'change_useraddress'),(153,'Can delete User address',49,'delete_useraddress'),(154,'Can add Country',50,'add_country'),(155,'Can change Country',50,'change_country'),(156,'Can delete Country',50,'delete_country'),(157,'Can add Payment Event Quantity',51,'add_paymenteventquantity'),(158,'Can change Payment Event Quantity',51,'change_paymenteventquantity'),(159,'Can delete Payment Event Quantity',51,'delete_paymenteventquantity'),(160,'Can add Shipping Event Quantity',52,'add_shippingeventquantity'),(161,'Can change Shipping Event Quantity',52,'change_shippingeventquantity'),(162,'Can delete Shipping Event Quantity',52,'delete_shippingeventquantity'),(163,'Can add Order',53,'add_order'),(164,'Can change Order',53,'change_order'),(165,'Can delete Order',53,'delete_order'),(166,'Can view orders (eg for reporting)',53,'can_view'),(167,'Can add Order Note',54,'add_ordernote'),(168,'Can change Order Note',54,'change_ordernote'),(169,'Can delete Order Note',54,'delete_ordernote'),(170,'Can add Communication Event',55,'add_communicationevent'),(171,'Can change Communication Event',55,'change_communicationevent'),(172,'Can delete Communication Event',55,'delete_communicationevent'),(173,'Can add Shipping address',56,'add_shippingaddress'),(174,'Can change Shipping address',56,'change_shippingaddress'),(175,'Can delete Shipping address',56,'delete_shippingaddress'),(176,'Can add billing address',57,'add_billingaddress'),(177,'Can change billing address',57,'change_billingaddress'),(178,'Can delete billing address',57,'delete_billingaddress'),(179,'Can add Order Line',58,'add_line'),(180,'Can change Order Line',58,'change_line'),(181,'Can delete Order Line',58,'delete_line'),(182,'Can add Line Price',59,'add_lineprice'),(183,'Can change Line Price',59,'change_lineprice'),(184,'Can delete Line Price',59,'delete_lineprice'),(185,'Can add Line Attribute',60,'add_lineattribute'),(186,'Can change Line Attribute',60,'change_lineattribute'),(187,'Can delete Line Attribute',60,'delete_lineattribute'),(188,'Can add Shipping Event',61,'add_shippingevent'),(189,'Can change Shipping Event',61,'change_shippingevent'),(190,'Can delete Shipping Event',61,'delete_shippingevent'),(191,'Can add Shipping Event Type',62,'add_shippingeventtype'),(192,'Can change Shipping Event Type',62,'change_shippingeventtype'),(193,'Can delete Shipping Event Type',62,'delete_shippingeventtype'),(194,'Can add Payment Event',63,'add_paymentevent'),(195,'Can change Payment Event',63,'change_paymentevent'),(196,'Can delete Payment Event',63,'delete_paymentevent'),(197,'Can add Payment Event Type',64,'add_paymenteventtype'),(198,'Can change Payment Event Type',64,'change_paymenteventtype'),(199,'Can delete Payment Event Type',64,'delete_paymenteventtype'),(200,'Can add Order Discount',65,'add_orderdiscount'),(201,'Can change Order Discount',65,'change_orderdiscount'),(202,'Can delete Order Discount',65,'delete_orderdiscount'),(203,'Can add Order and Item Charge',66,'add_orderanditemcharges'),(204,'Can change Order and Item Charge',66,'change_orderanditemcharges'),(205,'Can delete Order and Item Charge',66,'delete_orderanditemcharges'),(206,'Can add Weight-based Shipping Method',67,'add_weightbased'),(207,'Can change Weight-based Shipping Method',67,'change_weightbased'),(208,'Can delete Weight-based Shipping Method',67,'delete_weightbased'),(209,'Can add Weight Band',68,'add_weightband'),(210,'Can change Weight Band',68,'change_weightband'),(211,'Can delete Weight Band',68,'delete_weightband'),(212,'Can add Conditional offer',69,'add_conditionaloffer'),(213,'Can change Conditional offer',69,'change_conditionaloffer'),(214,'Can delete Conditional offer',69,'delete_conditionaloffer'),(215,'Can add Condition',70,'add_condition'),(216,'Can change Condition',70,'change_condition'),(217,'Can delete Condition',70,'delete_condition'),(218,'Can add Benefit',71,'add_benefit'),(219,'Can change Benefit',71,'change_benefit'),(220,'Can delete Benefit',71,'delete_benefit'),(221,'Can add Range',72,'add_range'),(222,'Can change Range',72,'change_range'),(223,'Can delete Range',72,'delete_range'),(224,'Can add Count Condition',70,'add_countcondition'),(225,'Can change Count Condition',70,'change_countcondition'),(226,'Can delete Count Condition',70,'delete_countcondition'),(227,'Can add Coverage Condition',70,'add_coveragecondition'),(228,'Can change Coverage Condition',70,'change_coveragecondition'),(229,'Can delete Coverage Condition',70,'delete_coveragecondition'),(230,'Can add Value Condition',70,'add_valuecondition'),(231,'Can change Value Condition',70,'change_valuecondition'),(232,'Can delete Value Condition',70,'delete_valuecondition'),(233,'Can add Percentage discount benefit',71,'add_percentagediscountbenefit'),(234,'Can change Percentage discount benefit',71,'change_percentagediscountbenefit'),(235,'Can delete Percentage discount benefit',71,'delete_percentagediscountbenefit'),(236,'Can add Absolute discount benefit',71,'add_absolutediscountbenefit'),(237,'Can change Absolute discount benefit',71,'change_absolutediscountbenefit'),(238,'Can delete Absolute discount benefit',71,'delete_absolutediscountbenefit'),(239,'Can add Fixed price benefit',71,'add_fixedpricebenefit'),(240,'Can change Fixed price benefit',71,'change_fixedpricebenefit'),(241,'Can delete Fixed price benefit',71,'delete_fixedpricebenefit'),(242,'Can add Multibuy discount benefit',71,'add_multibuydiscountbenefit'),(243,'Can change Multibuy discount benefit',71,'change_multibuydiscountbenefit'),(244,'Can delete Multibuy discount benefit',71,'delete_multibuydiscountbenefit'),(245,'Can add shipping benefit',71,'add_shippingbenefit'),(246,'Can change shipping benefit',71,'change_shippingbenefit'),(247,'Can delete shipping benefit',71,'delete_shippingbenefit'),(248,'Can add Shipping absolute discount benefit',71,'add_shippingabsolutediscountbenefit'),(249,'Can change Shipping absolute discount benefit',71,'change_shippingabsolutediscountbenefit'),(250,'Can delete Shipping absolute discount benefit',71,'delete_shippingabsolutediscountbenefit'),(251,'Can add Fixed price shipping benefit',71,'add_shippingfixedpricebenefit'),(252,'Can change Fixed price shipping benefit',71,'change_shippingfixedpricebenefit'),(253,'Can delete Fixed price shipping benefit',71,'delete_shippingfixedpricebenefit'),(254,'Can add Shipping percentage discount benefit',71,'add_shippingpercentagediscountbenefit'),(255,'Can change Shipping percentage discount benefit',71,'change_shippingpercentagediscountbenefit'),(256,'Can delete Shipping percentage discount benefit',71,'delete_shippingpercentagediscountbenefit'),(257,'Can add Voucher',84,'add_voucher'),(258,'Can change Voucher',84,'change_voucher'),(259,'Can delete Voucher',84,'delete_voucher'),(260,'Can add Voucher Application',85,'add_voucherapplication'),(261,'Can change Voucher Application',85,'change_voucherapplication'),(262,'Can delete Voucher Application',85,'delete_voucherapplication'),(263,'Can add Basket',86,'add_basket'),(264,'Can change Basket',86,'change_basket'),(265,'Can delete Basket',86,'delete_basket'),(266,'Can add Basket line',87,'add_line'),(267,'Can change Basket line',87,'change_line'),(268,'Can delete Basket line',87,'delete_line'),(269,'Can add Line attribute',88,'add_lineattribute'),(270,'Can change Line attribute',88,'change_lineattribute'),(271,'Can delete Line attribute',88,'delete_lineattribute'),(272,'Can add Transaction',89,'add_transaction'),(273,'Can change Transaction',89,'change_transaction'),(274,'Can delete Transaction',89,'delete_transaction'),(275,'Can add Source',90,'add_source'),(276,'Can change Source',90,'change_source'),(277,'Can delete Source',90,'delete_source'),(278,'Can add Source Type',91,'add_sourcetype'),(279,'Can change Source Type',91,'change_sourcetype'),(280,'Can delete Source Type',91,'delete_sourcetype'),(281,'Can add Bankcard',92,'add_bankcard'),(282,'Can change Bankcard',92,'change_bankcard'),(283,'Can delete Bankcard',92,'delete_bankcard'),(284,'Can add Range Product Uploaded File',93,'add_rangeproductfileupload'),(285,'Can change Range Product Uploaded File',93,'change_rangeproductfileupload'),(286,'Can delete Range Product Uploaded File',93,'delete_rangeproductfileupload'),(287,'Can add Page Promotion',94,'add_pagepromotion'),(288,'Can change Page Promotion',94,'change_pagepromotion'),(289,'Can delete Page Promotion',94,'delete_pagepromotion'),(290,'Can add Keyword Promotion',95,'add_keywordpromotion'),(291,'Can change Keyword Promotion',95,'change_keywordpromotion'),(292,'Can delete Keyword Promotion',95,'delete_keywordpromotion'),(293,'Can add Raw HTML',96,'add_rawhtml'),(294,'Can change Raw HTML',96,'change_rawhtml'),(295,'Can delete Raw HTML',96,'delete_rawhtml'),(296,'Can add Image',97,'add_image'),(297,'Can change Image',97,'change_image'),(298,'Can delete Image',97,'delete_image'),(299,'Can add Multi Image',98,'add_multiimage'),(300,'Can change Multi Image',98,'change_multiimage'),(301,'Can delete Multi Image',98,'delete_multiimage'),(302,'Can add Single Product',99,'add_singleproduct'),(303,'Can change Single Product',99,'change_singleproduct'),(304,'Can delete Single Product',99,'delete_singleproduct'),(305,'Can add Hand Picked Product List',100,'add_handpickedproductlist'),(306,'Can change Hand Picked Product List',100,'change_handpickedproductlist'),(307,'Can delete Hand Picked Product List',100,'delete_handpickedproductlist'),(308,'Can add Ordered Product',101,'add_orderedproduct'),(309,'Can change Ordered Product',101,'change_orderedproduct'),(310,'Can delete Ordered Product',101,'delete_orderedproduct'),(311,'Can add Automatic Product List',102,'add_automaticproductlist'),(312,'Can change Automatic Product List',102,'change_automaticproductlist'),(313,'Can delete Automatic Product List',102,'delete_automaticproductlist'),(314,'Can add Ordered Product List',103,'add_orderedproductlist'),(315,'Can change Ordered Product List',103,'change_orderedproductlist'),(316,'Can delete Ordered Product List',103,'delete_orderedproductlist'),(317,'Can add Tabbed Block',104,'add_tabbedblock'),(318,'Can change Tabbed Block',104,'change_tabbedblock'),(319,'Can delete Tabbed Block',104,'delete_tabbedblock'),(320,'Can add attribute option thumbnail',105,'add_attributeoptionthumbnail'),(321,'Can change attribute option thumbnail',105,'change_attributeoptionthumbnail'),(322,'Can delete attribute option thumbnail',105,'delete_attributeoptionthumbnail');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(75) NOT NULL,
  `password` varchar(128) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `last_login` datetime NOT NULL,
  `date_joined` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (1,'admin@theimip.com','Dave','E','admin@theimip.com','pbkdf2_sha256$10000$7LOIoIF8xFMC$tOCK3xUhRJGQcSf7hUz+2FVinspaf6DiCzrjSLFvld4=',1,1,1,'2013-05-20 12:16:27','2013-05-08 14:28:24'),(2,'NHKSMq4B3eAkx57aq94mHrgHgdZHf1','','','pankhida29@gmail.com','pbkdf2_sha256$10000$6sVYOi3vNp9z$raT+cABf9ZPGL4iK+rzzVO9bYrKFkE+hm4jFotyYxIc=',0,1,0,'2013-05-14 18:08:22','2013-05-14 18:08:20'),(3,'Roberto','','','','pbkdf2_sha256$10000$kBYr4pdbWW0O$+K+Yv4v2C4pm+lo8vMXgEfWm/GmVgtIYiMizOgETAMY=',0,1,0,'2013-05-17 06:44:59','2013-05-17 06:44:59'),(4,'Developer','','','info@theimip.com','pbkdf2_sha256$10000$9QGVbWf25hhT$VAjnVSEEQud5dSK04sSkvLH6Fh64dWUFbzOpnxGH4Ps=',1,1,1,'2013-05-21 11:47:05','2013-05-17 06:45:45');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`group_id`),
  KEY `auth_user_groups_fbfc09f1` (`user_id`),
  KEY `auth_user_groups_bda51c3c` (`group_id`),
  CONSTRAINT `group_id_refs_id_f0ee9890` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `user_id_refs_id_831107f1` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`permission_id`),
  KEY `auth_user_user_permissions_fbfc09f1` (`user_id`),
  KEY `auth_user_user_permissions_1e014c8f` (`permission_id`),
  CONSTRAINT `permission_id_refs_id_67e79cb` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `user_id_refs_id_f2045483` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=952 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
INSERT INTO `auth_user_user_permissions` VALUES (635,4,1),(636,4,2),(637,4,3),(638,4,4),(639,4,5),(640,4,6),(641,4,7),(642,4,8),(643,4,9),(644,4,10),(645,4,11),(646,4,12),(647,4,13),(648,4,14),(649,4,15),(650,4,16),(651,4,17),(652,4,18),(653,4,19),(654,4,20),(655,4,21),(656,4,22),(657,4,23),(658,4,24),(659,4,25),(660,4,26),(661,4,27),(662,4,28),(663,4,29),(664,4,30),(665,4,31),(666,4,32),(667,4,33),(668,4,34),(669,4,35),(670,4,36),(671,4,37),(672,4,38),(673,4,39),(674,4,40),(675,4,41),(676,4,42),(677,4,43),(678,4,44),(679,4,45),(680,4,46),(681,4,47),(682,4,48),(683,4,49),(684,4,50),(685,4,51),(686,4,52),(687,4,55),(688,4,56),(689,4,57),(690,4,58),(691,4,59),(692,4,60),(693,4,61),(694,4,62),(695,4,63),(696,4,64),(697,4,65),(698,4,66),(699,4,67),(700,4,68),(701,4,69),(702,4,70),(703,4,71),(704,4,72),(705,4,73),(706,4,74),(707,4,75),(708,4,76),(709,4,77),(710,4,78),(711,4,79),(712,4,80),(713,4,81),(714,4,82),(715,4,83),(716,4,84),(717,4,85),(718,4,86),(719,4,87),(720,4,88),(721,4,89),(722,4,90),(723,4,91),(724,4,92),(725,4,93),(726,4,94),(727,4,95),(728,4,96),(729,4,97),(730,4,98),(731,4,99),(732,4,100),(733,4,101),(734,4,102),(735,4,103),(736,4,104),(737,4,105),(738,4,106),(739,4,107),(740,4,108),(741,4,109),(742,4,110),(743,4,111),(744,4,112),(745,4,113),(746,4,114),(747,4,115),(748,4,116),(749,4,117),(750,4,118),(751,4,119),(752,4,120),(753,4,121),(754,4,122),(755,4,123),(756,4,124),(757,4,125),(758,4,126),(759,4,127),(760,4,128),(761,4,129),(762,4,130),(763,4,131),(764,4,132),(765,4,133),(766,4,134),(767,4,135),(768,4,136),(769,4,137),(770,4,138),(771,4,139),(772,4,140),(773,4,141),(774,4,142),(775,4,143),(776,4,144),(777,4,145),(778,4,146),(779,4,147),(780,4,148),(781,4,149),(782,4,150),(783,4,151),(784,4,152),(785,4,153),(786,4,154),(787,4,155),(788,4,156),(789,4,157),(790,4,158),(791,4,159),(792,4,160),(793,4,161),(794,4,162),(795,4,163),(796,4,164),(797,4,165),(798,4,166),(799,4,167),(800,4,168),(801,4,169),(802,4,170),(803,4,171),(804,4,172),(805,4,173),(806,4,174),(807,4,175),(808,4,176),(809,4,177),(810,4,178),(811,4,179),(812,4,180),(813,4,181),(814,4,182),(815,4,183),(816,4,184),(817,4,185),(818,4,186),(819,4,187),(820,4,188),(821,4,189),(822,4,190),(823,4,191),(824,4,192),(825,4,193),(826,4,194),(827,4,195),(828,4,196),(829,4,197),(830,4,198),(831,4,199),(832,4,200),(833,4,201),(834,4,202),(835,4,203),(836,4,204),(837,4,205),(838,4,206),(839,4,207),(840,4,208),(841,4,209),(842,4,210),(843,4,211),(844,4,212),(845,4,213),(846,4,214),(847,4,215),(848,4,216),(849,4,217),(850,4,218),(851,4,219),(852,4,220),(853,4,221),(854,4,222),(855,4,223),(856,4,224),(857,4,225),(858,4,226),(859,4,227),(860,4,228),(861,4,229),(862,4,230),(863,4,231),(864,4,232),(865,4,233),(866,4,234),(867,4,235),(868,4,236),(869,4,237),(870,4,238),(871,4,239),(872,4,240),(873,4,241),(874,4,242),(875,4,243),(876,4,244),(877,4,245),(878,4,246),(879,4,247),(880,4,248),(881,4,249),(882,4,250),(883,4,251),(884,4,252),(885,4,253),(886,4,254),(887,4,255),(888,4,256),(889,4,257),(890,4,258),(891,4,259),(892,4,260),(893,4,261),(894,4,262),(895,4,263),(896,4,264),(897,4,265),(898,4,266),(899,4,267),(900,4,268),(901,4,269),(902,4,270),(903,4,271),(904,4,272),(905,4,273),(906,4,274),(907,4,275),(908,4,276),(909,4,277),(910,4,278),(911,4,279),(912,4,280),(913,4,281),(914,4,282),(915,4,283),(916,4,284),(917,4,285),(918,4,286),(919,4,287),(920,4,288),(921,4,289),(922,4,290),(923,4,291),(924,4,292),(925,4,293),(926,4,294),(927,4,295),(928,4,296),(929,4,297),(930,4,298),(931,4,299),(932,4,300),(933,4,301),(934,4,302),(935,4,303),(936,4,304),(937,4,305),(938,4,306),(939,4,307),(940,4,308),(941,4,309),(942,4,310),(943,4,311),(944,4,312),(945,4,313),(946,4,314),(947,4,315),(948,4,316),(949,4,317),(950,4,318),(951,4,319);
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `basket_basket`
--

DROP TABLE IF EXISTS `basket_basket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `basket_basket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner_id` int(11) DEFAULT NULL,
  `status` varchar(128) NOT NULL,
  `date_created` datetime NOT NULL,
  `date_merged` datetime DEFAULT NULL,
  `date_submitted` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `basket_basket_5d52dd10` (`owner_id`),
  CONSTRAINT `owner_id_refs_id_606b1d81d48428a` FOREIGN KEY (`owner_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `basket_basket`
--

LOCK TABLES `basket_basket` WRITE;
/*!40000 ALTER TABLE `basket_basket` DISABLE KEYS */;
INSERT INTO `basket_basket` VALUES (1,1,'Open','2013-05-08 14:28:37',NULL,NULL),(2,2,'Open','2013-05-14 18:08:22',NULL,NULL),(3,4,'Open','2013-05-20 17:34:34',NULL,NULL);
/*!40000 ALTER TABLE `basket_basket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `basket_basket_vouchers`
--

DROP TABLE IF EXISTS `basket_basket_vouchers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `basket_basket_vouchers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `basket_id` int(11) NOT NULL,
  `voucher_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `basket_basket_vouchers_basket_id_42d9f11e1a94f93a_uniq` (`basket_id`,`voucher_id`),
  KEY `basket_basket_vouchers_7e9d6c10` (`basket_id`),
  KEY `basket_basket_vouchers_7a302bdb` (`voucher_id`),
  CONSTRAINT `basket_id_refs_id_68df49e622deaf04` FOREIGN KEY (`basket_id`) REFERENCES `basket_basket` (`id`),
  CONSTRAINT `voucher_id_refs_id_265f4531c5be385c` FOREIGN KEY (`voucher_id`) REFERENCES `voucher_voucher` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `basket_basket_vouchers`
--

LOCK TABLES `basket_basket_vouchers` WRITE;
/*!40000 ALTER TABLE `basket_basket_vouchers` DISABLE KEYS */;
/*!40000 ALTER TABLE `basket_basket_vouchers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `basket_line`
--

DROP TABLE IF EXISTS `basket_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `basket_line` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `basket_id` int(11) NOT NULL,
  `line_reference` varchar(128) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(10) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `price_incl_tax` decimal(12,2),
  `price_excl_tax` decimal(12,2),
  PRIMARY KEY (`id`),
  UNIQUE KEY `basket_line_basket_id_7d0d707a7fd92c45_uniq` (`basket_id`,`line_reference`),
  KEY `basket_line_7e9d6c10` (`basket_id`),
  KEY `basket_line_1a33377f` (`line_reference`),
  KEY `basket_line_bb420c12` (`product_id`),
  CONSTRAINT `basket_id_refs_id_6c25b1c2b38e16cd` FOREIGN KEY (`basket_id`) REFERENCES `basket_basket` (`id`),
  CONSTRAINT `product_id_refs_id_258face575c99eb7` FOREIGN KEY (`product_id`) REFERENCES `catalogue_product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `basket_line`
--

LOCK TABLES `basket_line` WRITE;
/*!40000 ALTER TABLE `basket_line` DISABLE KEYS */;
/*!40000 ALTER TABLE `basket_line` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `basket_lineattribute`
--

DROP TABLE IF EXISTS `basket_lineattribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `basket_lineattribute` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `line_id` int(11) NOT NULL,
  `option_id` int(11) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `basket_lineattribute_92b3444a` (`line_id`),
  KEY `basket_lineattribute_2f3b0dc9` (`option_id`),
  CONSTRAINT `line_id_refs_id_72fc976903a5d486` FOREIGN KEY (`line_id`) REFERENCES `basket_line` (`id`),
  CONSTRAINT `option_id_refs_id_6bccdc7b87752759` FOREIGN KEY (`option_id`) REFERENCES `catalogue_option` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `basket_lineattribute`
--

LOCK TABLES `basket_lineattribute` WRITE;
/*!40000 ALTER TABLE `basket_lineattribute` DISABLE KEYS */;
/*!40000 ALTER TABLE `basket_lineattribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogue_attributeentity`
--

DROP TABLE IF EXISTS `catalogue_attributeentity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalogue_attributeentity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `type_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catalogue_attributeentity_a951d5d6` (`slug`),
  KEY `catalogue_attributeentity_777d41c8` (`type_id`),
  CONSTRAINT `type_id_refs_id_2c339b53c6b2bf55` FOREIGN KEY (`type_id`) REFERENCES `catalogue_attributeentitytype` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogue_attributeentity`
--

LOCK TABLES `catalogue_attributeentity` WRITE;
/*!40000 ALTER TABLE `catalogue_attributeentity` DISABLE KEYS */;
/*!40000 ALTER TABLE `catalogue_attributeentity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogue_attributeentitytype`
--

DROP TABLE IF EXISTS `catalogue_attributeentitytype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalogue_attributeentitytype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catalogue_attributeentitytype_a951d5d6` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogue_attributeentitytype`
--

LOCK TABLES `catalogue_attributeentitytype` WRITE;
/*!40000 ALTER TABLE `catalogue_attributeentitytype` DISABLE KEYS */;
INSERT INTO `catalogue_attributeentitytype` VALUES (1,'Product Options','product-options'),(2,'Paper Options','paper-options');
/*!40000 ALTER TABLE `catalogue_attributeentitytype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogue_attributeoption`
--

DROP TABLE IF EXISTS `catalogue_attributeoption`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalogue_attributeoption` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `option` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catalogue_attributeoption_bda51c3c` (`group_id`),
  CONSTRAINT `group_id_refs_id_5c565a7c9541f55` FOREIGN KEY (`group_id`) REFERENCES `catalogue_attributeoptiongroup` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogue_attributeoption`
--

LOCK TABLES `catalogue_attributeoption` WRITE;
/*!40000 ALTER TABLE `catalogue_attributeoption` DISABLE KEYS */;
INSERT INTO `catalogue_attributeoption` VALUES (1,2,'Portrait'),(2,2,'Landscape'),(3,1,'Custom'),(4,1,'A4'),(5,1,'A3'),(6,3,'190gsm'),(7,4,'Satin'),(8,5,'None'),(9,5,'Gloss'),(10,5,'Matt'),(11,5,'Gloss Encapsulation');
/*!40000 ALTER TABLE `catalogue_attributeoption` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogue_attributeoptiongroup`
--

DROP TABLE IF EXISTS `catalogue_attributeoptiongroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalogue_attributeoptiongroup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogue_attributeoptiongroup`
--

LOCK TABLES `catalogue_attributeoptiongroup` WRITE;
/*!40000 ALTER TABLE `catalogue_attributeoptiongroup` DISABLE KEYS */;
INSERT INTO `catalogue_attributeoptiongroup` VALUES (1,'Paper Size'),(2,'Orientation'),(3,'Paper Weight'),(4,'Paper Type'),(5,'Lamination or Encapsulation');
/*!40000 ALTER TABLE `catalogue_attributeoptiongroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogue_category`
--

DROP TABLE IF EXISTS `catalogue_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalogue_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `path` varchar(255) NOT NULL,
  `depth` int(10) unsigned NOT NULL,
  `numchild` int(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `description` longtext,
  `image` varchar(100),
  PRIMARY KEY (`id`),
  UNIQUE KEY `path` (`path`),
  KEY `catalogue_category_52094d6e` (`name`),
  KEY `catalogue_category_a951d5d6` (`slug`),
  KEY `catalogue_category_8b99b45` (`full_name`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogue_category`
--

LOCK TABLES `catalogue_category` WRITE;
/*!40000 ALTER TABLE `catalogue_category` DISABLE KEYS */;
INSERT INTO `catalogue_category` VALUES (1,'0001',1,0,'Booklets','booklets','Booklets','',''),(2,'0002',1,0,'Leaflets','leaflets','Leaflets','',''),(3,'0003',1,0,'Banners','banners','Banners','',''),(4,'0004',1,0,'Canvas','canvas','Canvas','',''),(5,'0005',1,0,'Board and Panels','board-and-panels','Board and Panels','',''),(6,'0006',1,0,'Foamex 3mm & 5mm ','foamex-3mm-5mm','Foamex 3mm & 5mm ','',''),(7,'0007',1,0,'Artist Canvas','artist-canvas','Artist Canvas','',''),(8,'0008',1,0,'Exhibition Materials','exhibition-materials','Exhibition Materials','',''),(9,'0009',1,0,'Prints','prints','Prints','',''),(10,'000A',1,0,'Posters','posters','Posters','',''),(11,'000B',1,0,'Stationery','stationery','Stationery','',''),(12,'000C',1,0,'Stickers','stickers','Stickers','',''),(13,'000D',1,0,'Vinyl','vinyl','Vinyl','',''),(14,'000E',1,0,'Wallpaper','wallpaper','Wallpaper','','');
/*!40000 ALTER TABLE `catalogue_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogue_contributor`
--

DROP TABLE IF EXISTS `catalogue_contributor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalogue_contributor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catalogue_contributor_a951d5d6` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogue_contributor`
--

LOCK TABLES `catalogue_contributor` WRITE;
/*!40000 ALTER TABLE `catalogue_contributor` DISABLE KEYS */;
/*!40000 ALTER TABLE `catalogue_contributor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogue_contributorrole`
--

DROP TABLE IF EXISTS `catalogue_contributorrole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalogue_contributorrole` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `name_plural` varchar(50) NOT NULL,
  `slug` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catalogue_contributorrole_a951d5d6` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogue_contributorrole`
--

LOCK TABLES `catalogue_contributorrole` WRITE;
/*!40000 ALTER TABLE `catalogue_contributorrole` DISABLE KEYS */;
/*!40000 ALTER TABLE `catalogue_contributorrole` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogue_option`
--

DROP TABLE IF EXISTS `catalogue_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalogue_option` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `code` varchar(128) NOT NULL,
  `type` varchar(128) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `catalogue_option_code_1687c916225230f1_uniq` (`code`),
  KEY `catalogue_option_65da3d2c` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogue_option`
--

LOCK TABLES `catalogue_option` WRITE;
/*!40000 ALTER TABLE `catalogue_option` DISABLE KEYS */;
/*!40000 ALTER TABLE `catalogue_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogue_product`
--

DROP TABLE IF EXISTS `catalogue_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalogue_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `upc` varchar(64) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(255) NOT NULL,
  `description` longtext,
  `product_class_id` int(11) DEFAULT NULL,
  `score` double NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  `status` varchar(128),
  `is_discountable` tinyint(1) NOT NULL,
  `rating` double,
  PRIMARY KEY (`id`),
  UNIQUE KEY `catalogue_product_upc_47091a7974ee95de_uniq` (`upc`),
  KEY `catalogue_product_a7ad2e7a` (`upc`),
  KEY `catalogue_product_63f17a16` (`parent_id`),
  KEY `catalogue_product_a951d5d6` (`slug`),
  KEY `catalogue_product_ee50fea3` (`product_class_id`),
  KEY `catalogue_product_3fa9fe1c` (`score`),
  KEY `catalogue_product_bdd0404b` (`date_updated`),
  KEY `catalogue_product_c9ad71dd` (`status`),
  CONSTRAINT `parent_id_refs_id_6b68f9b554004f89` FOREIGN KEY (`parent_id`) REFERENCES `catalogue_product` (`id`),
  CONSTRAINT `product_class_id_refs_id_7f530a175e5d81d0` FOREIGN KEY (`product_class_id`) REFERENCES `catalogue_productclass` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogue_product`
--

LOCK TABLES `catalogue_product` WRITE;
/*!40000 ALTER TABLE `catalogue_product` DISABLE KEYS */;
INSERT INTO `catalogue_product` VALUES (1,'eragrgrgdsfg',NULL,'Banner 100x100','banner-100x100','Stop your co-workers in their tracks with the stunning new 30-inch diagonal HP LP3065 Flat Panel Monitor. This flagship monitor features best-in-class performance and presentation features on a huge wide-aspect screen while letting you work as comfortably as possible - you might even forget you\'re at the office',1,0,'2013-05-11 07:32:14','2013-05-21 10:15:37',NULL,1,NULL);
/*!40000 ALTER TABLE `catalogue_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogue_product_product_options`
--

DROP TABLE IF EXISTS `catalogue_product_product_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalogue_product_product_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `option_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `catalogue_product_product_opti_product_id_72c840707f278a98_uniq` (`product_id`,`option_id`),
  KEY `catalogue_product_product_options_bb420c12` (`product_id`),
  KEY `catalogue_product_product_options_2f3b0dc9` (`option_id`),
  CONSTRAINT `option_id_refs_id_6519b7c68094e2a3` FOREIGN KEY (`option_id`) REFERENCES `catalogue_option` (`id`),
  CONSTRAINT `product_id_refs_id_742a32557edeb694` FOREIGN KEY (`product_id`) REFERENCES `catalogue_product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogue_product_product_options`
--

LOCK TABLES `catalogue_product_product_options` WRITE;
/*!40000 ALTER TABLE `catalogue_product_product_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `catalogue_product_product_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogue_product_related_products`
--

DROP TABLE IF EXISTS `catalogue_product_related_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalogue_product_related_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_product_id` int(11) NOT NULL,
  `to_product_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `catalogue_product_related_from_product_id_6dc96f22461ac2e7_uniq` (`from_product_id`,`to_product_id`),
  KEY `catalogue_product_related_products_c884f964` (`from_product_id`),
  KEY `catalogue_product_related_products_5bd7a0dd` (`to_product_id`),
  CONSTRAINT `from_product_id_refs_id_7e61993b6e267779` FOREIGN KEY (`from_product_id`) REFERENCES `catalogue_product` (`id`),
  CONSTRAINT `to_product_id_refs_id_7e61993b6e267779` FOREIGN KEY (`to_product_id`) REFERENCES `catalogue_product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogue_product_related_products`
--

LOCK TABLES `catalogue_product_related_products` WRITE;
/*!40000 ALTER TABLE `catalogue_product_related_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `catalogue_product_related_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogue_productattribute`
--

DROP TABLE IF EXISTS `catalogue_productattribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalogue_productattribute` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_class_id` int(11) DEFAULT NULL,
  `name` varchar(128) NOT NULL,
  `code` varchar(128) NOT NULL,
  `type` varchar(20) NOT NULL,
  `option_group_id` int(11) DEFAULT NULL,
  `entity_type_id` int(11) DEFAULT NULL,
  `required` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catalogue_productattribute_ee50fea3` (`product_class_id`),
  KEY `catalogue_productattribute_65da3d2c` (`code`),
  KEY `catalogue_productattribute_2619a0bd` (`option_group_id`),
  KEY `catalogue_productattribute_299a9dd7` (`entity_type_id`),
  CONSTRAINT `entity_type_id_refs_id_3ebafaae1823dca6` FOREIGN KEY (`entity_type_id`) REFERENCES `catalogue_attributeentitytype` (`id`),
  CONSTRAINT `option_group_id_refs_id_7dd94478231034b8` FOREIGN KEY (`option_group_id`) REFERENCES `catalogue_attributeoptiongroup` (`id`),
  CONSTRAINT `product_class_id_refs_id_f86ceb69a0e83f` FOREIGN KEY (`product_class_id`) REFERENCES `catalogue_productclass` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogue_productattribute`
--

LOCK TABLES `catalogue_productattribute` WRITE;
/*!40000 ALTER TABLE `catalogue_productattribute` DISABLE KEYS */;
INSERT INTO `catalogue_productattribute` VALUES (1,1,'Paper Size','papersize','multi_option',1,1,1),(2,1,'Orientation','orientation','multi_option',2,1,0),(3,1,'Paper Weight','paperweight','multi_option',3,2,0),(4,1,'Paper Type','papertype','multi_option',4,2,0),(5,1,'Lamination or Encapsulation','laminationorencapsulation','multi_option',5,2,0);
/*!40000 ALTER TABLE `catalogue_productattribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogue_productattributevalue`
--

DROP TABLE IF EXISTS `catalogue_productattributevalue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalogue_productattributevalue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `value_text` varchar(255) DEFAULT NULL,
  `value_integer` int(11) DEFAULT NULL,
  `value_boolean` tinyint(1),
  `value_float` double DEFAULT NULL,
  `value_richtext` longtext,
  `value_date` date DEFAULT NULL,
  `value_option_id` int(11) DEFAULT NULL,
  `value_entity_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `catalogue_productattributevalue_f2eca69f` (`attribute_id`),
  KEY `catalogue_productattributevalue_bb420c12` (`product_id`),
  KEY `catalogue_productattributevalue_b30b9e13` (`value_option_id`),
  KEY `catalogue_productattributevalue_b1beb8af` (`value_entity_id`),
  CONSTRAINT `attribute_id_refs_id_18ff9b3149e1af6f` FOREIGN KEY (`attribute_id`) REFERENCES `catalogue_productattribute` (`id`),
  CONSTRAINT `product_id_refs_id_20af8418d17731ca` FOREIGN KEY (`product_id`) REFERENCES `catalogue_product` (`id`),
  CONSTRAINT `value_entity_id_refs_id_516a5aef23964e26` FOREIGN KEY (`value_entity_id`) REFERENCES `catalogue_attributeentity` (`id`),
  CONSTRAINT `value_option_id_refs_id_4014176cac0f16d4` FOREIGN KEY (`value_option_id`) REFERENCES `catalogue_attributeoption` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogue_productattributevalue`
--

LOCK TABLES `catalogue_productattributevalue` WRITE;
/*!40000 ALTER TABLE `catalogue_productattributevalue` DISABLE KEYS */;
INSERT INTO `catalogue_productattributevalue` VALUES (1,5,1,NULL,NULL,0,NULL,NULL,NULL,9,NULL),(2,2,1,NULL,NULL,0,NULL,NULL,NULL,1,NULL),(3,1,1,NULL,NULL,0,NULL,NULL,NULL,4,NULL),(4,4,1,NULL,NULL,0,NULL,NULL,NULL,7,NULL),(5,3,1,NULL,NULL,0,NULL,NULL,NULL,6,NULL);
/*!40000 ALTER TABLE `catalogue_productattributevalue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogue_productattributevalue_value_multi_option`
--

DROP TABLE IF EXISTS `catalogue_productattributevalue_value_multi_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalogue_productattributevalue_value_multi_option` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `productattributevalue_id` int(11) NOT NULL,
  `attributeoption_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `catalogue_produc_productattributevalue_id_47780e19e8a7662d_uniq` (`productattributevalue_id`,`attributeoption_id`),
  KEY `catalogue_productattributevalue_value_multi_option_79b89a43` (`productattributevalue_id`),
  KEY `catalogue_productattributevalue_value_multi_option_15f18b18` (`attributeoption_id`),
  CONSTRAINT `attributeoption_id_refs_id_5cb094f34577c99d` FOREIGN KEY (`attributeoption_id`) REFERENCES `catalogue_attributeoption` (`id`),
  CONSTRAINT `productattributevalue_id_refs_id_73f469749b37ec0c` FOREIGN KEY (`productattributevalue_id`) REFERENCES `catalogue_productattributevalue` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogue_productattributevalue_value_multi_option`
--

LOCK TABLES `catalogue_productattributevalue_value_multi_option` WRITE;
/*!40000 ALTER TABLE `catalogue_productattributevalue_value_multi_option` DISABLE KEYS */;
INSERT INTO `catalogue_productattributevalue_value_multi_option` VALUES (1,1,8),(2,1,10),(3,2,1),(4,3,3),(5,3,4),(6,4,7),(7,5,6);
/*!40000 ALTER TABLE `catalogue_productattributevalue_value_multi_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogue_productcategory`
--

DROP TABLE IF EXISTS `catalogue_productcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalogue_productcategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `is_canonical` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catalogue_productcategory_bb420c12` (`product_id`),
  KEY `catalogue_productcategory_42dc49bc` (`category_id`),
  KEY `catalogue_productcategory_5497fa04` (`is_canonical`),
  CONSTRAINT `category_id_refs_id_3a9b0c18213322e9` FOREIGN KEY (`category_id`) REFERENCES `catalogue_category` (`id`),
  CONSTRAINT `product_id_refs_id_1f6cc3825453006b` FOREIGN KEY (`product_id`) REFERENCES `catalogue_product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogue_productcategory`
--

LOCK TABLES `catalogue_productcategory` WRITE;
/*!40000 ALTER TABLE `catalogue_productcategory` DISABLE KEYS */;
INSERT INTO `catalogue_productcategory` VALUES (1,1,3,0);
/*!40000 ALTER TABLE `catalogue_productcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogue_productclass`
--

DROP TABLE IF EXISTS `catalogue_productclass`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalogue_productclass` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `slug` varchar(128) NOT NULL,
  `requires_shipping` tinyint(1) NOT NULL,
  `track_stock` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogue_productclass`
--

LOCK TABLES `catalogue_productclass` WRITE;
/*!40000 ALTER TABLE `catalogue_productclass` DISABLE KEYS */;
INSERT INTO `catalogue_productclass` VALUES (1,'Banners','banners',1,1),(2,'Booklets','booklets',1,1),(3,'Bords & Panels','bords-panels',1,1),(4,'Leaflets','leaflets',1,1),(5,'Canvas','canvas',1,1);
/*!40000 ALTER TABLE `catalogue_productclass` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogue_productclass_options`
--

DROP TABLE IF EXISTS `catalogue_productclass_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalogue_productclass_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `productclass_id` int(11) NOT NULL,
  `option_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `catalogue_productclass_op_productclass_id_415b3580371dcd90_uniq` (`productclass_id`,`option_id`),
  KEY `catalogue_productclass_options_4c96c09` (`productclass_id`),
  KEY `catalogue_productclass_options_2f3b0dc9` (`option_id`),
  CONSTRAINT `option_id_refs_id_1faa8090a32cc06c` FOREIGN KEY (`option_id`) REFERENCES `catalogue_option` (`id`),
  CONSTRAINT `productclass_id_refs_id_2f40050356fe557e` FOREIGN KEY (`productclass_id`) REFERENCES `catalogue_productclass` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogue_productclass_options`
--

LOCK TABLES `catalogue_productclass_options` WRITE;
/*!40000 ALTER TABLE `catalogue_productclass_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `catalogue_productclass_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogue_productcontributor`
--

DROP TABLE IF EXISTS `catalogue_productcontributor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalogue_productcontributor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `contributor_id` int(11) NOT NULL,
  `role_id` int(11),
  PRIMARY KEY (`id`),
  KEY `catalogue_productcontributor_bb420c12` (`product_id`),
  KEY `catalogue_productcontributor_6a73a0c4` (`contributor_id`),
  KEY `catalogue_productcontributor_bf07f040` (`role_id`),
  CONSTRAINT `contributor_id_refs_id_2bd923ffbb40a89f` FOREIGN KEY (`contributor_id`) REFERENCES `catalogue_contributor` (`id`),
  CONSTRAINT `product_id_refs_id_8265302f06c19bb` FOREIGN KEY (`product_id`) REFERENCES `catalogue_product` (`id`),
  CONSTRAINT `role_id_refs_id_295709b2fa6b73ef` FOREIGN KEY (`role_id`) REFERENCES `catalogue_contributorrole` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogue_productcontributor`
--

LOCK TABLES `catalogue_productcontributor` WRITE;
/*!40000 ALTER TABLE `catalogue_productcontributor` DISABLE KEYS */;
/*!40000 ALTER TABLE `catalogue_productcontributor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogue_productimage`
--

DROP TABLE IF EXISTS `catalogue_productimage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalogue_productimage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `original` varchar(100) NOT NULL,
  `caption` varchar(200) DEFAULT NULL,
  `display_order` int(10) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `catalogue_productimage_product_id_13868d064d886d95_uniq` (`product_id`,`display_order`),
  KEY `catalogue_productimage_bb420c12` (`product_id`),
  CONSTRAINT `product_id_refs_id_61170617011aab1` FOREIGN KEY (`product_id`) REFERENCES `catalogue_product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogue_productimage`
--

LOCK TABLES `catalogue_productimage` WRITE;
/*!40000 ALTER TABLE `catalogue_productimage` DISABLE KEYS */;
INSERT INTO `catalogue_productimage` VALUES (1,1,'images/products/2013/05/lGCONljtbA.jpg','',0,'2013-05-11 08:20:04');
/*!40000 ALTER TABLE `catalogue_productimage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogue_productrecommendation`
--

DROP TABLE IF EXISTS `catalogue_productrecommendation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalogue_productrecommendation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `primary_id` int(11) NOT NULL,
  `recommendation_id` int(11) NOT NULL,
  `ranking` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catalogue_productrecommendation_f8d5ed73` (`primary_id`),
  KEY `catalogue_productrecommendation_7bfcf8af` (`recommendation_id`),
  CONSTRAINT `primary_id_refs_id_135e24f25d6d0838` FOREIGN KEY (`primary_id`) REFERENCES `catalogue_product` (`id`),
  CONSTRAINT `recommendation_id_refs_id_135e24f25d6d0838` FOREIGN KEY (`recommendation_id`) REFERENCES `catalogue_product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogue_productrecommendation`
--

LOCK TABLES `catalogue_productrecommendation` WRITE;
/*!40000 ALTER TABLE `catalogue_productrecommendation` DISABLE KEYS */;
/*!40000 ALTER TABLE `catalogue_productrecommendation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `csvimport_csvimport`
--

DROP TABLE IF EXISTS `csvimport_csvimport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `csvimport_csvimport` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model_name` varchar(255) NOT NULL,
  `field_list` varchar(255) NOT NULL,
  `upload_file` varchar(100) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `encoding` varchar(32) NOT NULL,
  `upload_method` varchar(50) NOT NULL,
  `error_log` longtext NOT NULL,
  `import_date` date NOT NULL,
  `import_user` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `csvimport_csvimport`
--

LOCK TABLES `csvimport_csvimport` WRITE;
/*!40000 ALTER TABLE `csvimport_csvimport` DISABLE KEYS */;
/*!40000 ALTER TABLE `csvimport_csvimport` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `csvimport_importmodel`
--

DROP TABLE IF EXISTS `csvimport_importmodel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `csvimport_importmodel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `csvimport_id` int(11) NOT NULL,
  `numeric_id` int(10) unsigned NOT NULL,
  `natural_key` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `csvimport_importmodel_fe08e486` (`csvimport_id`),
  CONSTRAINT `csvimport_id_refs_id_8d3261cc` FOREIGN KEY (`csvimport_id`) REFERENCES `csvimport_csvimport` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `csvimport_importmodel`
--

LOCK TABLES `csvimport_importmodel` WRITE;
/*!40000 ALTER TABLE `csvimport_importmodel` DISABLE KEYS */;
/*!40000 ALTER TABLE `csvimport_importmodel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_communicationeventtype`
--

DROP TABLE IF EXISTS `customer_communicationeventtype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_communicationeventtype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(128) NOT NULL,
  `name` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `email_subject_template` varchar(255),
  `email_body_template` longtext,
  `email_body_html_template` longtext,
  `sms_template` varchar(170) NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_communicationeventtype_65da3d2c` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_communicationeventtype`
--

LOCK TABLES `customer_communicationeventtype` WRITE;
/*!40000 ALTER TABLE `customer_communicationeventtype` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_communicationeventtype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_email`
--

DROP TABLE IF EXISTS `customer_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_email` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `subject` longtext NOT NULL,
  `body_text` longtext NOT NULL,
  `body_html` longtext,
  `date_sent` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_email_fbfc09f1` (`user_id`),
  CONSTRAINT `user_id_refs_id_616ffdfa01dae763` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_email`
--

LOCK TABLES `customer_email` WRITE;
/*!40000 ALTER TABLE `customer_email` DISABLE KEYS */;
INSERT INTO `customer_email` VALUES (1,2,'Thank you for registering.','Thank you for registering.','<p>Thank you for registering.</p>','2013-05-14 18:08:21'),(2,1,'Resetting your password at example.com.','\nYou\'re receiving this e-mail because you requested a password reset for your user account at example.com.\n\nPlease go to the following page and choose a new password:\nhttp://example.com/password-reset/confirm/1-3hg-5c289e4f863a85017985/\n\nThanks for using our site!\nThe example.com team\n\n\n','\n<p>\n	You\'re receiving this e-mail because you requested a password reset for your user account at example.com.\n</p>\n\n<p>Please go to the following page and choose a new password:</p>\nhttp://example.com/password-reset/confirm/1-3hg-5c289e4f863a85017985/\n\n<p>Thanks for using our site!</p>\n<p>The example.com team</p>\n\n\n','2013-05-14 20:31:02'),(3,1,'Resetting your password at example.com.','\nYou\'re receiving this e-mail because you requested a password reset for your user account at example.com.\n\nPlease go to the following page and choose a new password:\nhttp://example.com/password-reset/confirm/1-3hg-5c289e4f863a85017985/\n\nThanks for using our site!\nThe example.com team\n\n\n','\n<p>\n	You\'re receiving this e-mail because you requested a password reset for your user account at example.com.\n</p>\n\n<p>Please go to the following page and choose a new password:</p>\nhttp://example.com/password-reset/confirm/1-3hg-5c289e4f863a85017985/\n\n<p>Thanks for using our site!</p>\n<p>The example.com team</p>\n\n\n','2013-05-14 21:08:55'),(4,1,'Your password changed at example.com.','\n\n\nYou\'re receiving this email because your password has been changed at example.com.\n\n\nIf it wasn\'t you who changed it, please reset your password immediately:\nhttp://example.com/password-reset/confirm/1-3hi-e3e419730252af0847ad/\n\nOtherwise, you can ignore this email.\n\nThanks for using our site!\nThe example.com team\n\n\n','\n\n<p>\n    \n    You\'re receiving this e-mail because your password has been changed at example.com.\n    \n</p>\n\n<p>\nIf it wasn\'t you who changed it, please reset your password immediately:\nhttp://example.com/password-reset/confirm/1-3hi-e3e419730252af0847ad/\n</p>\n\n<p>Otherwise, you can ignore this email.</p>\n\n<p>Thanks for using our site!</p>\n<p>The example.com team</p>\n\n','2013-05-16 17:04:37'),(5,1,'Your password changed at example.com.','\n\n\nYou\'re receiving this email because your password has been changed at example.com.\n\n\nIf it wasn\'t you who changed it, please reset your password immediately:\nhttp://example.com/password-reset/confirm/1-3hm-d0fbf8e6f50f92dbc1e0/\n\nOtherwise, you can ignore this email.\n\nThanks for using our site!\nThe example.com team\n\n\n','\n\n<p>\n    \n    You\'re receiving this e-mail because your password has been changed at example.com.\n    \n</p>\n\n<p>\nIf it wasn\'t you who changed it, please reset your password immediately:\nhttp://example.com/password-reset/confirm/1-3hm-d0fbf8e6f50f92dbc1e0/\n</p>\n\n<p>Otherwise, you can ignore this email.</p>\n\n<p>Thanks for using our site!</p>\n<p>The example.com team</p>\n\n','2013-05-20 15:52:42');
/*!40000 ALTER TABLE `customer_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_notification`
--

DROP TABLE IF EXISTS `customer_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `recipient_id` int(11) NOT NULL,
  `sender_id` int(11) DEFAULT NULL,
  `subject` varchar(255) NOT NULL,
  `body` longtext NOT NULL,
  `category` varchar(255) DEFAULT NULL,
  `location` varchar(32) NOT NULL,
  `date_sent` datetime NOT NULL,
  `date_read` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_notification_fcd09624` (`recipient_id`),
  KEY `customer_notification_901f59e9` (`sender_id`),
  CONSTRAINT `recipient_id_refs_id_1153954ea079c19f` FOREIGN KEY (`recipient_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `sender_id_refs_id_1153954ea079c19f` FOREIGN KEY (`sender_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_notification`
--

LOCK TABLES `customer_notification` WRITE;
/*!40000 ALTER TABLE `customer_notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_productalert`
--

DROP TABLE IF EXISTS `customer_productalert`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_productalert` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `email` varchar(75) DEFAULT NULL,
  `key` varchar(128) DEFAULT NULL,
  `status` varchar(20) NOT NULL,
  `date_created` datetime NOT NULL,
  `date_confirmed` datetime DEFAULT NULL,
  `date_cancelled` datetime DEFAULT NULL,
  `date_closed` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_productalert_bb420c12` (`product_id`),
  KEY `customer_productalert_fbfc09f1` (`user_id`),
  KEY `customer_productalert_3904588a` (`email`),
  KEY `customer_productalert_45544485` (`key`),
  CONSTRAINT `product_id_refs_id_415e4f4bc471f1aa` FOREIGN KEY (`product_id`) REFERENCES `catalogue_product` (`id`),
  CONSTRAINT `user_id_refs_id_6d57e4aa3c62edcb` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_productalert`
--

LOCK TABLES `customer_productalert` WRITE;
/*!40000 ALTER TABLE `customer_productalert` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_productalert` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_fbfc09f1` (`user_id`),
  KEY `django_admin_log_e4470c6e` (`content_type_id`),
  CONSTRAINT `content_type_id_refs_id_288599e6` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `user_id_refs_id_c8665aa` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (1,'2013-05-10 13:14:52',1,27,'1','Banners',1,''),(2,'2013-05-10 13:15:00',1,27,'2','Booklets',1,''),(3,'2013-05-10 13:15:08',1,27,'3','Bords & Panels',1,''),(4,'2013-05-10 13:15:13',1,27,'4','Leaflets',1,''),(5,'2013-05-10 13:15:24',1,27,'4','Leaflets',2,'Changed slug.'),(6,'2013-05-10 13:15:37',1,27,'4','Leaflets',2,'Changed slug.'),(7,'2013-05-10 13:15:49',1,27,'5','Canvas',1,''),(8,'2013-05-11 08:31:56',1,46,'1','The Main Partner',1,''),(9,'2013-05-12 15:31:05',1,39,'1','Product Options',1,''),(10,'2013-05-12 15:31:16',1,39,'2','Paper Options',1,''),(11,'2013-05-12 15:33:07',1,36,'1','Paper Size',1,''),(12,'2013-05-12 15:33:28',1,36,'2','Orientation',1,''),(13,'2013-05-12 15:33:44',1,36,'1','Paper Size',2,'Added Attribute Option \"Custom\". Added Attribute Option \"A4\". Added Attribute Option \"A3\".'),(14,'2013-05-12 15:34:30',1,36,'3','Paper Weight',1,''),(15,'2013-05-12 15:34:41',1,36,'4','Paper Type',1,''),(16,'2013-05-12 15:35:03',1,36,'5','Lamination or Encapsulation',1,''),(17,'2013-05-12 15:36:31',1,34,'1','Paper Size',1,''),(18,'2013-05-12 15:36:58',1,34,'2','Orientation',1,''),(19,'2013-05-12 15:37:27',1,34,'3','Paper Weight',1,''),(20,'2013-05-12 15:37:53',1,34,'4','Paper Type',1,''),(21,'2013-05-12 15:38:13',1,34,'5','Lamination or Encapsulation',1,''),(22,'2013-05-12 15:41:55',1,34,'1','Paper Size',2,'Changed entity_type.'),(23,'2013-05-12 15:42:03',1,34,'2','Orientation',2,'No fields changed.'),(24,'2013-05-12 15:42:17',1,34,'3','Paper Weight',2,'Changed entity_type.'),(25,'2013-05-12 15:42:25',1,34,'5','Lamination or Encapsulation',2,'No fields changed.'),(26,'2013-05-12 15:42:33',1,34,'4','Paper Type',2,'Changed entity_type.'),(27,'2013-05-12 15:53:33',1,34,'1','Paper Size',2,'Changed type.'),(28,'2013-05-12 15:53:45',1,34,'5','Lamination or Encapsulation',2,'Changed type.'),(29,'2013-05-12 15:53:50',1,34,'2','Orientation',2,'No fields changed.'),(30,'2013-05-12 15:53:56',1,34,'1','Paper Size',2,'No fields changed.'),(31,'2013-05-12 15:54:01',1,34,'4','Paper Type',2,'Changed type.'),(32,'2013-05-12 15:54:07',1,34,'3','Paper Weight',2,'Changed type.'),(33,'2013-05-12 21:10:04',1,34,'5','Lamination or Encapsulation',2,'Changed entity_type.'),(34,'2013-05-12 21:10:19',1,34,'3','Paper Weight',2,'Changed entity_type.'),(35,'2013-05-12 21:10:27',1,34,'4','Paper Type',2,'Changed entity_type.'),(36,'2013-05-12 21:10:38',1,34,'3','Paper Weight',2,'No fields changed.'),(37,'2013-05-17 06:45:00',1,3,'3','Roberto',1,''),(38,'2013-05-17 06:45:46',1,3,'4','Rob',1,''),(39,'2013-05-17 06:49:14',1,3,'4','Rob',2,'Changed password, email, is_superuser and user_permissions.'),(40,'2013-05-17 06:50:25',1,3,'4','Rob',2,'Changed password and is_staff.'),(41,'2013-05-20 12:17:08',1,105,'1','AttributeOptionThumbnail object',1,''),(42,'2013-05-20 15:58:28',1,3,'4','Developer',2,'Changed username and password.'),(43,'2013-05-21 11:47:33',4,105,'1','AttributeOptionThumbnail object',2,'Changed img.'),(44,'2013-05-21 11:47:43',4,105,'2','AttributeOptionThumbnail object',1,''),(45,'2013-05-21 11:47:53',4,105,'3','AttributeOptionThumbnail object',1,''),(46,'2013-05-21 11:48:02',4,105,'4','AttributeOptionThumbnail object',1,'');
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `app_label` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=107 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'permission','auth','permission'),(2,'group','auth','group'),(3,'user','auth','user'),(4,'content type','contenttypes','contenttype'),(5,'session','sessions','session'),(6,'site','sites','site'),(7,'flat page','flatpages','flatpage'),(8,'log entry','admin','logentry'),(9,'migration history','south','migrationhistory'),(10,'Product Review','reviews','productreview'),(11,'Vote','reviews','vote'),(12,'kv store','thumbnail','kvstore'),(13,'csv import','csvimport','csvimport'),(14,'import model','csvimport','importmodel'),(15,'bookmark','menu','bookmark'),(16,'dashboard preferences','dashboard','dashboardpreferences'),(17,'account type','accounts','accounttype'),(18,'account','accounts','account'),(19,'transfer','accounts','transfer'),(20,'transaction','accounts','transaction'),(21,'IP address record','accounts','ipaddressrecord'),(22,'Email','customer','email'),(23,'Communication event type','customer','communicationeventtype'),(24,'notification','customer','notification'),(25,'product alert','customer','productalert'),(26,'Product Recommendation','catalogue','productrecommendation'),(27,'Product Class','catalogue','productclass'),(28,'Category','catalogue','category'),(29,'Product Category','catalogue','productcategory'),(30,'Product','catalogue','product'),(31,'Contributor Role','catalogue','contributorrole'),(32,'Contributor','catalogue','contributor'),(33,'Product Contributor','catalogue','productcontributor'),(34,'Product Attribute','catalogue','productattribute'),(35,'Product Attribute Value','catalogue','productattributevalue'),(36,'Attribute Option Group','catalogue','attributeoptiongroup'),(37,'Attribute Option','catalogue','attributeoption'),(38,'Attribute Entity','catalogue','attributeentity'),(39,'Attribute Entity Type','catalogue','attributeentitytype'),(40,'Option','catalogue','option'),(41,'Product Image','catalogue','productimage'),(42,'Product record','analytics','productrecord'),(43,'User Record','analytics','userrecord'),(44,'Basket','analytics','userproductview'),(45,'user search','analytics','usersearch'),(46,'Fulfillment partner','partner','partner'),(47,'Stock Record','partner','stockrecord'),(48,'Stock Alert','partner','stockalert'),(49,'User address','address','useraddress'),(50,'Country','address','country'),(51,'Payment Event Quantity','order','paymenteventquantity'),(52,'Shipping Event Quantity','order','shippingeventquantity'),(53,'Order','order','order'),(54,'Order Note','order','ordernote'),(55,'Communication Event','order','communicationevent'),(56,'Shipping address','order','shippingaddress'),(57,'billing address','order','billingaddress'),(58,'Order Line','order','line'),(59,'Line Price','order','lineprice'),(60,'Line Attribute','order','lineattribute'),(61,'Shipping Event','order','shippingevent'),(62,'Shipping Event Type','order','shippingeventtype'),(63,'Payment Event','order','paymentevent'),(64,'Payment Event Type','order','paymenteventtype'),(65,'Order Discount','order','orderdiscount'),(66,'Order and Item Charge','shipping','orderanditemcharges'),(67,'Weight-based Shipping Method','shipping','weightbased'),(68,'Weight Band','shipping','weightband'),(69,'Conditional offer','offer','conditionaloffer'),(70,'Condition','offer','condition'),(71,'Benefit','offer','benefit'),(72,'Range','offer','range'),(73,'Fixed price shipping benefit','offer','shippingfixedpricebenefit'),(74,'Coverage Condition','offer','coveragecondition'),(75,'Count Condition','offer','countcondition'),(76,'Value Condition','offer','valuecondition'),(77,'Multibuy discount benefit','offer','multibuydiscountbenefit'),(78,'Shipping percentage discount benefit','offer','shippingpercentagediscountbenefit'),(79,'shipping benefit','offer','shippingbenefit'),(80,'Shipping absolute discount benefit','offer','shippingabsolutediscountbenefit'),(81,'Percentage discount benefit','offer','percentagediscountbenefit'),(82,'Absolute discount benefit','offer','absolutediscountbenefit'),(83,'Fixed price benefit','offer','fixedpricebenefit'),(84,'Voucher','voucher','voucher'),(85,'Voucher Application','voucher','voucherapplication'),(86,'Basket','basket','basket'),(87,'Basket line','basket','line'),(88,'Line attribute','basket','lineattribute'),(89,'Transaction','payment','transaction'),(90,'Source','payment','source'),(91,'Source Type','payment','sourcetype'),(92,'Bankcard','payment','bankcard'),(93,'Range Product Uploaded File','ranges','rangeproductfileupload'),(94,'Page Promotion','promotions','pagepromotion'),(95,'Keyword Promotion','promotions','keywordpromotion'),(96,'Raw HTML','promotions','rawhtml'),(97,'Image','promotions','image'),(98,'Multi Image','promotions','multiimage'),(99,'Single Product','promotions','singleproduct'),(100,'Hand Picked Product List','promotions','handpickedproductlist'),(101,'Ordered Product','promotions','orderedproduct'),(102,'Automatic Product List','promotions','automaticproductlist'),(103,'Ordered Product List','promotions','orderedproductlist'),(104,'Tabbed Block','promotions','tabbedblock'),(105,'attribute option thumbnail','gap','attributeoptionthumbnail'),(106,'attribute option thumbnail','catalogue','attributeoptionthumbnail');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_flatpage`
--

DROP TABLE IF EXISTS `django_flatpage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_flatpage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(100) NOT NULL,
  `title` varchar(200) NOT NULL,
  `content` longtext NOT NULL,
  `enable_comments` tinyint(1) NOT NULL,
  `template_name` varchar(70) NOT NULL,
  `registration_required` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_flatpage_a4b49ab` (`url`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_flatpage`
--

LOCK TABLES `django_flatpage` WRITE;
/*!40000 ALTER TABLE `django_flatpage` DISABLE KEYS */;
INSERT INTO `django_flatpage` VALUES (1,'/contact/','Contact Us','Contact Page',0,'',0),(2,'/corporate-policies/','Corporate Policies','',0,'',0),(3,'/services/','Services','',0,'',0),(4,'/about/','About Us','',0,'',0),(5,'/delivery/','Delivery','',0,'',0),(6,'/privacy-policy/','Privacy Policy','',0,'',0),(7,'/terms-and-conditions/','Terms and Conditions','',0,'',0),(8,'/returns/','Returns Policy','',0,'',0),(9,'/help/','Help','',0,'',0),(10,'/social-media-links/','Social Media Links','',0,'',0),(11,'/support/','Support','',0,'',0),(12,'/account-support/','My Account support','',0,'',0),(13,'/how-it-works/','How it works','',0,'',0);
/*!40000 ALTER TABLE `django_flatpage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_flatpage_sites`
--

DROP TABLE IF EXISTS `django_flatpage_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_flatpage_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `flatpage_id` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `flatpage_id` (`flatpage_id`,`site_id`),
  KEY `django_flatpage_sites_dedefef8` (`flatpage_id`),
  KEY `django_flatpage_sites_6223029` (`site_id`),
  CONSTRAINT `flatpage_id_refs_id_c0e84f5a` FOREIGN KEY (`flatpage_id`) REFERENCES `django_flatpage` (`id`),
  CONSTRAINT `site_id_refs_id_4e3eeb57` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_flatpage_sites`
--

LOCK TABLES `django_flatpage_sites` WRITE;
/*!40000 ALTER TABLE `django_flatpage_sites` DISABLE KEYS */;
INSERT INTO `django_flatpage_sites` VALUES (1,1,1),(2,2,1),(3,3,1),(4,4,1),(5,5,1),(6,6,1),(7,7,1),(8,8,1),(9,9,1),(10,10,1),(11,11,1),(12,12,1),(13,13,1);
/*!40000 ALTER TABLE `django_flatpage_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_c25c2c28` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('0662c1873f127d047712d46a605f912b','NjdkMmE4Yjg5NTM1NGNhMzZmZGE4MWY2MTJjZGEzZmU1NjkxMDYzNzqAAn1xAShVDV9hdXRoX3Vz\nZXJfaWSKAQRVEl9hdXRoX3VzZXJfYmFja2VuZFUub3NjYXIuYXBwcy5jdXN0b21lci5hdXRoX2Jh\nY2tlbmRzLkVtYWlsYmFja2VuZFUHb3B0aW9uc11xAihYAQAAADJYAQAAADRldS4=\n','2013-06-05 07:56:19'),('07a756921d4dd6bf00d2281c920711d9','YmFkMTAzZmQyZWRkNTZlMmJjMTQxMzU2ZDBhYzgzZDA4MzBmODNiNjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVS5vc2Nhci5hcHBzLmN1c3RvbWVyLmF1dGhfYmFja2VuZHMuRW1haWxiYWNr\nZW5kcQNVB29wdGlvbnNdVQ1fYXV0aF91c2VyX2lkcQSKAQF1Lg==\n','2013-06-03 12:16:27'),('08c8922b640dfc3b058de65939427446','Zjc3ZTY4ODgwOWI0YTMwMDY5ZTE1NjY5MzE2OTRiNzUwNDNkM2FlZDqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n','2013-05-29 06:26:39'),('08f9f74cca4d389d0f3ff2dd05bd5358','MGE2NTE2NmViOTZlOWVmMzFhOWFmZmM3YWY1MWYzOWQ2OTIxMzY1YzqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n','2013-05-24 18:24:37'),('0a3bcf8829a55bbca18b1bbc8339e3a5','OTZiZGQyNGRiNzFlN2JmMGQyN2IxZGQzYzQyZTk3ZDdkOTJiMjA0ZDqAAn1xAShVCnRlc3Rjb29r\naWVVBndvcmtlZFUHb3B0aW9uc111Lg==\n','2013-05-29 13:20:02'),('1991996c29595336953bcff8fd4f1a61','OWRhODVmZTEzOTEzMDIzZTRkOTQxNDQ5ZDQzZTljNmUzN2UzNDAzZjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZFUub3NjYXIuYXBwcy5jdXN0b21lci5hdXRoX2JhY2tlbmRzLkVtYWlsYmFja2Vu\nZFUNX2F1dGhfdXNlcl9pZIoBBFUHb3B0aW9uc111Lg==\n','2013-06-03 22:47:29'),('1bb5238c0aa16b190b0e622c303a412a','Zjc3ZTY4ODgwOWI0YTMwMDY5ZTE1NjY5MzE2OTRiNzUwNDNkM2FlZDqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n','2013-05-31 16:33:39'),('1c5e1391251a371c4050e537f7d1d195','MWE3ZmYxNzYyNWFlMTFlZjU2MzY2YWY5MjRlMWVmZjc0ZmYyNmI5NDqAAn1xAShVDV9hdXRoX3Vz\nZXJfaWSKAQFVEl9hdXRoX3VzZXJfYmFja2VuZFUub3NjYXIuYXBwcy5jdXN0b21lci5hdXRoX2Jh\nY2tlbmRzLkVtYWlsYmFja2VuZFUHb3B0aW9uc111Lg==\n','2013-05-26 21:48:43'),('1e057dbde7b6125f5772386b4b7bcc71','NDk0NDZlMTZlMDM1YzY3OTE0ZTA5Y2QwNWZlYzFjOTcyYTU1MTE5OTqAAn1xAShVCnRlc3Rjb29r\naWVxAlUGd29ya2VkcQNVB29wdGlvbnNddS4=\n','2013-05-29 11:41:12'),('2d81e9766763909c0b665453c716c529','Zjc3ZTY4ODgwOWI0YTMwMDY5ZTE1NjY5MzE2OTRiNzUwNDNkM2FlZDqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n','2013-06-02 21:23:53'),('3281059f57dedbf4bf6ca8f73e086008','Zjc3ZTY4ODgwOWI0YTMwMDY5ZTE1NjY5MzE2OTRiNzUwNDNkM2FlZDqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n','2013-06-02 21:24:26'),('3404b13143ebaf7f1dd9907ec690bce4','MGE2NTE2NmViOTZlOWVmMzFhOWFmZmM3YWY1MWYzOWQ2OTIxMzY1YzqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n','2013-05-29 16:05:14'),('554213001a0c7d3bbf151ab0f36d281e','Zjc3ZTY4ODgwOWI0YTMwMDY5ZTE1NjY5MzE2OTRiNzUwNDNkM2FlZDqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n','2013-06-01 08:25:00'),('5565d370342d0123f7fbaafa3ddfc2e0','NGQ2ODE0YzY0Mzg5NmYwNDZjZDc3MTNkZmExNjA2ZGNhYWZiYmNlOTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVS5vc2Nhci5hcHBzLmN1c3RvbWVyLmF1dGhfYmFja2VuZHMuRW1haWxiYWNr\nZW5kcQNVDV9hdXRoX3VzZXJfaWRxBIoBAnUu\n','2013-05-28 18:08:22'),('5b508eace2d085a693b893b37a368c84','ODdkODJkNmFkZjJhNmYyOWIwYzA2MTg4MzE1MWJjNWVmMTkzMzA3MTqAAn1xAShVCnRlc3Rjb29r\naWVVBndvcmtlZHECVQdvcHRpb25zXXUu\n','2013-06-03 12:14:10'),('64c34252eb99fcf0b0a2a377984df0c6','ZDQ3YmMzZWY5MmViOWMzOTI2NmRkNmFlZmQ0ZTRlMzczY2Q3M2FhOTqAAn1xAShVDV9hdXRoX3Vz\nZXJfaWSKAQFVEl9hdXRoX3VzZXJfYmFja2VuZFUub3NjYXIuYXBwcy5jdXN0b21lci5hdXRoX2Jh\nY2tlbmRzLkVtYWlsYmFja2VuZFUHb3B0aW9uc11xAihYAQAAADJYAQAAADRldS4=\n','2013-06-03 23:05:59'),('818223b455ff96100de6f845425fa2c5','OTNlNTRkMTc4ZjYyMzU5NDRhMzE4NGRkOTJjNzA0YmQ1YTYzOGRkYjqAAn1xAShVDG9mZmVyX3dp\nemFyZH1xAihVDG1ldGFkYXRhX29iamNkamFuZ28uZGIubW9kZWxzLmJhc2UKbW9kZWxfdW5waWNr\nbGUKcQNjb3NjYXIuYXBwcy5vZmZlci5tb2RlbHMKQ29uZGl0aW9uYWxPZmZlcgpxBF1jZGphbmdv\nLmRiLm1vZGVscy5iYXNlCnNpbXBsZV9jbGFzc19mYWN0b3J5CnEFh1JxBn1xByhVBnN0YXR1c3EI\nWAQAAABPcGVuVRdtYXhfZ2xvYmFsX2FwcGxpY2F0aW9uc3EJTlUOc3RhcnRfZGF0ZXRpbWVxCk5V\nFW1heF91c2VyX2FwcGxpY2F0aW9uc3ELTlULZGVzY3JpcHRpb25xDFgAAAAAVQpudW1fb3JkZXJz\ncQ1LAFUOdG90YWxfZGlzY291bnRxDmNkZWNpbWFsCkRlY2ltYWwKcQ9VBDAuMDCFUnEQVQxyZWRp\ncmVjdF91cmxxEVUAVQZfc3RhdGVxEmNkamFuZ28uZGIubW9kZWxzLmJhc2UKTW9kZWxTdGF0ZQpx\nEymBcRR9cRUoVQZhZGRpbmdxFohVAmRicRdOdWJVDGNvbmRpdGlvbl9pZHEYTlUCaWRxGU5VCHBy\naW9yaXR5cRpLAFUKYmVuZWZpdF9pZHEbTlUMbWF4X2Rpc2NvdW50cRxOVQxlbmRfZGF0ZXRpbWVx\nHU5VF21heF9iYXNrZXRfYXBwbGljYXRpb25zcR5OVQxkYXRlX2NyZWF0ZWRxH05VCm9mZmVyX3R5\ncGVxIFgEAAAAU2l0ZVUEc2x1Z3EhTlUQbnVtX2FwcGxpY2F0aW9uc3EiSwBVBG5hbWVxI1gCAAAA\nMTFxJHViVQhtZXRhZGF0YXElfXEmVQRkYXRhcSd9cSgoVQRuYW1lcSloJFULZGVzY3JpcHRpb25x\nKlgAAAAAdXN1VRJfYXV0aF91c2VyX2JhY2tlbmRVLm9zY2FyLmFwcHMuY3VzdG9tZXIuYXV0aF9i\nYWNrZW5kcy5FbWFpbGJhY2tlbmRVDV9hdXRoX3VzZXJfaWSKAQF1Lg==\n','2013-05-25 10:30:25'),('82a415475098316cbbd9aab38dd8c625','MjlkYjE4YjY4YmQ3NzJjYjJmNzNmZTZlNGI1ZjQwYzM3M2YyN2Y1ZjqAAn1xAShVCnRlc3Rjb29r\naWVVBndvcmtlZFUHb3B0aW9uc3ECXXUu\n','2013-05-31 10:54:18'),('8e07cdac111bf070bf0f2d1b05e21f09','MWIxNDIwOTAzNGQ4MTBjY2E4NTQ4YTZkOWVkYjQwZDZjYjI5Yjc1ZjqAAn1xAVUHb3B0aW9uc3EC\nXXMu\n','2013-05-29 13:44:26'),('8f217e9cd446bd55a7e6c90481e43673','Zjc3ZTY4ODgwOWI0YTMwMDY5ZTE1NjY5MzE2OTRiNzUwNDNkM2FlZDqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n','2013-06-05 01:56:16'),('96fc6262728298ea3105ec17b12fe399','Zjc3ZTY4ODgwOWI0YTMwMDY5ZTE1NjY5MzE2OTRiNzUwNDNkM2FlZDqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n','2013-05-24 11:21:25'),('a140d9b145392654d01b5d4c1ecf8e9d','Zjc3ZTY4ODgwOWI0YTMwMDY5ZTE1NjY5MzE2OTRiNzUwNDNkM2FlZDqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n','2013-06-01 09:02:50'),('a6b8498f88fb92327d7cd70ae9115823','OTllNmVhZjM0N2QzZDlhZDdlODBiNDA3NTUwYzZjNmRkNzhlY2UwMjqAAn1xAS4=\n','2013-05-24 16:10:32'),('ac650193b52b8c6b4c15b29e2fde038d','Zjc3ZTY4ODgwOWI0YTMwMDY5ZTE1NjY5MzE2OTRiNzUwNDNkM2FlZDqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n','2013-05-27 23:11:51'),('b74f48a2d17b26dea8eacfc52b613721','MjlkYjE4YjY4YmQ3NzJjYjJmNzNmZTZlNGI1ZjQwYzM3M2YyN2Y1ZjqAAn1xAShVCnRlc3Rjb29r\naWVVBndvcmtlZFUHb3B0aW9uc3ECXXUu\n','2013-05-28 08:57:39'),('b92b081752bc9ba19dead57d4c4e5fa5','MWIxNDIwOTAzNGQ4MTBjY2E4NTQ4YTZkOWVkYjQwZDZjYjI5Yjc1ZjqAAn1xAVUHb3B0aW9uc3EC\nXXMu\n','2013-06-04 18:36:15'),('b97178c9f61685cb0daa8dcab641a6e0','MjlkYjE4YjY4YmQ3NzJjYjJmNzNmZTZlNGI1ZjQwYzM3M2YyN2Y1ZjqAAn1xAShVCnRlc3Rjb29r\naWVVBndvcmtlZFUHb3B0aW9uc3ECXXUu\n','2013-06-03 21:33:07'),('bad4772a8e5e6eeb2930332ae59851bd','MWIxNDIwOTAzNGQ4MTBjY2E4NTQ4YTZkOWVkYjQwZDZjYjI5Yjc1ZjqAAn1xAVUHb3B0aW9uc3EC\nXXMu\n','2013-05-28 10:09:00'),('bb81ea03611b0c2b1043fe686ae774f7','Zjc3ZTY4ODgwOWI0YTMwMDY5ZTE1NjY5MzE2OTRiNzUwNDNkM2FlZDqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n','2013-05-30 19:14:35'),('c25f1d57c01e086f14e6d50a6ab7b56b','NGFkZjJjNDZlY2E2MTUwZDVmN2JlZTk3MzI3NGRhYzkwNzY5NzljNTqAAn1xAShVDV9hdXRoX3Vz\nZXJfaWSKAQRVB29wdGlvbnNdVRJfYXV0aF91c2VyX2JhY2tlbmRVLm9zY2FyLmFwcHMuY3VzdG9t\nZXIuYXV0aF9iYWNrZW5kcy5FbWFpbGJhY2tlbmR1Lg==\n','2013-06-04 19:14:29'),('c82b487a88a53fe4319cd36fe7a2d4c2','Zjc3ZTY4ODgwOWI0YTMwMDY5ZTE1NjY5MzE2OTRiNzUwNDNkM2FlZDqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n','2013-06-02 21:11:26'),('d26bd6a13ba46445435a0d0d4ecf6fdb','NDFiNGIwMjVjZDEzNzM0ZGViY2FlOGY4ZTAwYTZjZThhOTUxOGY0NjqAAn1xAVUHb3B0aW9uc11z\nLg==\n','2013-06-02 19:38:45'),('d722e75b6e23824ce621b411930b2b2c','Zjc3ZTY4ODgwOWI0YTMwMDY5ZTE1NjY5MzE2OTRiNzUwNDNkM2FlZDqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n','2013-06-04 10:57:11'),('db71b1e4368000ed19463131d8f0ebcb','Zjc3ZTY4ODgwOWI0YTMwMDY5ZTE1NjY5MzE2OTRiNzUwNDNkM2FlZDqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n','2013-05-27 23:49:47'),('dd5b44453831408f6df3bcdcfd1e675d','Njg3OWUyMTQ5NjA4MjYzNDc2ZTA2M2MzZTVhMjU5NWNhZjIzNTljZDqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVS5vc2Nhci5hcHBzLmN1c3RvbWVyLmF1dGhfYmFja2VuZHMuRW1haWxiYWNr\nZW5kcQNVDV9hdXRoX3VzZXJfaWRxBIoBAXUu\n','2013-05-29 19:50:14'),('df601d4ac6c17a51825c59906014f700','MGE2NTE2NmViOTZlOWVmMzFhOWFmZmM3YWY1MWYzOWQ2OTIxMzY1YzqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n','2013-05-31 05:27:38'),('e033d4091fa5cec9456b059aaa98b794','Zjc3ZTY4ODgwOWI0YTMwMDY5ZTE1NjY5MzE2OTRiNzUwNDNkM2FlZDqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n','2013-05-27 23:11:51'),('eb4eefb07cf096d022d3d06591e63ec2','Zjc3ZTY4ODgwOWI0YTMwMDY5ZTE1NjY5MzE2OTRiNzUwNDNkM2FlZDqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n','2013-06-01 03:58:01'),('edfad93985db9fae2308cd8093e0d198','Njg3OWUyMTQ5NjA4MjYzNDc2ZTA2M2MzZTVhMjU5NWNhZjIzNTljZDqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVS5vc2Nhci5hcHBzLmN1c3RvbWVyLmF1dGhfYmFja2VuZHMuRW1haWxiYWNr\nZW5kcQNVDV9hdXRoX3VzZXJfaWRxBIoBAXUu\n','2013-05-24 14:44:00'),('f4443796c413817287f4e74f23072e06','Zjc3ZTY4ODgwOWI0YTMwMDY5ZTE1NjY5MzE2OTRiNzUwNDNkM2FlZDqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n','2013-05-27 23:35:53');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_site`
--

DROP TABLE IF EXISTS `django_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_site` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain` varchar(100) NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_site`
--

LOCK TABLES `django_site` WRITE;
/*!40000 ALTER TABLE `django_site` DISABLE KEYS */;
INSERT INTO `django_site` VALUES (1,'example.com','example.com');
/*!40000 ALTER TABLE `django_site` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gap_attributeoptionthumbnail`
--

DROP TABLE IF EXISTS `gap_attributeoptionthumbnail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gap_attributeoptionthumbnail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `img` varchar(100) NOT NULL,
  `option_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `option_id` (`option_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gap_attributeoptionthumbnail`
--

LOCK TABLES `gap_attributeoptionthumbnail` WRITE;
/*!40000 ALTER TABLE `gap_attributeoptionthumbnail` DISABLE KEYS */;
INSERT INTO `gap_attributeoptionthumbnail` VALUES (1,'gallery/portrait.gif',1),(2,'gallery/landscape.gif',2),(3,'gallery/item_2.gif',4),(4,'gallery/item_1.gif',5);
/*!40000 ALTER TABLE `gap_attributeoptionthumbnail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offer_benefit`
--

DROP TABLE IF EXISTS `offer_benefit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `offer_benefit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `range_id` int(11) DEFAULT NULL,
  `type` varchar(128),
  `value` decimal(12,2) DEFAULT NULL,
  `max_affected_items` int(10) unsigned DEFAULT NULL,
  `proxy_class` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `proxy_class` (`proxy_class`),
  KEY `offer_benefit_647ae97e` (`range_id`),
  CONSTRAINT `range_id_refs_id_37c969ae3fabdc23` FOREIGN KEY (`range_id`) REFERENCES `offer_range` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offer_benefit`
--

LOCK TABLES `offer_benefit` WRITE;
/*!40000 ALTER TABLE `offer_benefit` DISABLE KEYS */;
/*!40000 ALTER TABLE `offer_benefit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offer_condition`
--

DROP TABLE IF EXISTS `offer_condition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `offer_condition` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `range_id` int(11),
  `type` varchar(128),
  `value` decimal(12,2),
  `proxy_class` varchar(255),
  PRIMARY KEY (`id`),
  UNIQUE KEY `proxy_class` (`proxy_class`),
  KEY `offer_condition_647ae97e` (`range_id`),
  CONSTRAINT `range_id_refs_id_1e7eaa0975a43a55` FOREIGN KEY (`range_id`) REFERENCES `offer_range` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offer_condition`
--

LOCK TABLES `offer_condition` WRITE;
/*!40000 ALTER TABLE `offer_condition` DISABLE KEYS */;
/*!40000 ALTER TABLE `offer_condition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offer_conditionaloffer`
--

DROP TABLE IF EXISTS `offer_conditionaloffer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `offer_conditionaloffer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `description` longtext,
  `offer_type` varchar(128) NOT NULL,
  `condition_id` int(11) NOT NULL,
  `benefit_id` int(11) NOT NULL,
  `start_datetime` datetime DEFAULT NULL,
  `end_datetime` datetime DEFAULT NULL,
  `priority` int(11) NOT NULL,
  `total_discount` decimal(12,2) NOT NULL,
  `date_created` datetime NOT NULL,
  `redirect_url` varchar(200) NOT NULL,
  `num_orders` int(10) unsigned NOT NULL,
  `slug` varchar(128),
  `max_basket_applications` int(10) unsigned DEFAULT NULL,
  `max_global_applications` int(10) unsigned,
  `num_applications` int(10) unsigned NOT NULL,
  `max_user_applications` int(10) unsigned,
  `max_discount` decimal(12,2),
  `status` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `offer_conditionaloffer_name_3c29ac426cd12ce3_uniq` (`name`),
  UNIQUE KEY `slug` (`slug`),
  KEY `offer_conditionaloffer_115412aa` (`condition_id`),
  KEY `offer_conditionaloffer_c439f5be` (`benefit_id`),
  CONSTRAINT `benefit_id_refs_id_2a480383896eaff9` FOREIGN KEY (`benefit_id`) REFERENCES `offer_benefit` (`id`),
  CONSTRAINT `condition_id_refs_id_482b04c74cbf159f` FOREIGN KEY (`condition_id`) REFERENCES `offer_condition` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offer_conditionaloffer`
--

LOCK TABLES `offer_conditionaloffer` WRITE;
/*!40000 ALTER TABLE `offer_conditionaloffer` DISABLE KEYS */;
/*!40000 ALTER TABLE `offer_conditionaloffer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offer_range`
--

DROP TABLE IF EXISTS `offer_range`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `offer_range` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `includes_all_products` tinyint(1) NOT NULL,
  `date_created` datetime NOT NULL,
  `proxy_class` varchar(255),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `offer_range_proxy_class_7b62e7b2541da6a2_uniq` (`proxy_class`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offer_range`
--

LOCK TABLES `offer_range` WRITE;
/*!40000 ALTER TABLE `offer_range` DISABLE KEYS */;
INSERT INTO `offer_range` VALUES (1,'All Products',1,'2013-05-11 08:55:35',NULL);
/*!40000 ALTER TABLE `offer_range` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offer_range_classes`
--

DROP TABLE IF EXISTS `offer_range_classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `offer_range_classes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `range_id` int(11) NOT NULL,
  `productclass_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `offer_range_classes_range_id_bdcb6b196150337_uniq` (`range_id`,`productclass_id`),
  KEY `offer_range_classes_647ae97e` (`range_id`),
  KEY `offer_range_classes_4c96c09` (`productclass_id`),
  CONSTRAINT `productclass_id_refs_id_7a86d1e2ad9a6e34` FOREIGN KEY (`productclass_id`) REFERENCES `catalogue_productclass` (`id`),
  CONSTRAINT `range_id_refs_id_29566c470e41d468` FOREIGN KEY (`range_id`) REFERENCES `offer_range` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offer_range_classes`
--

LOCK TABLES `offer_range_classes` WRITE;
/*!40000 ALTER TABLE `offer_range_classes` DISABLE KEYS */;
/*!40000 ALTER TABLE `offer_range_classes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offer_range_excluded_products`
--

DROP TABLE IF EXISTS `offer_range_excluded_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `offer_range_excluded_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `range_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `offer_range_excluded_products_range_id_517164c1e1e8929f_uniq` (`range_id`,`product_id`),
  KEY `offer_range_excluded_products_647ae97e` (`range_id`),
  KEY `offer_range_excluded_products_bb420c12` (`product_id`),
  CONSTRAINT `product_id_refs_id_1765b916c933abc0` FOREIGN KEY (`product_id`) REFERENCES `catalogue_product` (`id`),
  CONSTRAINT `range_id_refs_id_11146fb51a830b0b` FOREIGN KEY (`range_id`) REFERENCES `offer_range` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offer_range_excluded_products`
--

LOCK TABLES `offer_range_excluded_products` WRITE;
/*!40000 ALTER TABLE `offer_range_excluded_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `offer_range_excluded_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offer_range_included_categories`
--

DROP TABLE IF EXISTS `offer_range_included_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `offer_range_included_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `range_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `offer_range_included_categories_range_id_1e886d89e69b6665_uniq` (`range_id`,`category_id`),
  KEY `offer_range_included_categories_647ae97e` (`range_id`),
  KEY `offer_range_included_categories_42dc49bc` (`category_id`),
  CONSTRAINT `category_id_refs_id_76a54aaa88b70c86` FOREIGN KEY (`category_id`) REFERENCES `catalogue_category` (`id`),
  CONSTRAINT `range_id_refs_id_188df0a5c2639403` FOREIGN KEY (`range_id`) REFERENCES `offer_range` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offer_range_included_categories`
--

LOCK TABLES `offer_range_included_categories` WRITE;
/*!40000 ALTER TABLE `offer_range_included_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `offer_range_included_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offer_range_included_products`
--

DROP TABLE IF EXISTS `offer_range_included_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `offer_range_included_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `range_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `offer_range_included_products_range_id_5653de41c69b5815_uniq` (`range_id`,`product_id`),
  KEY `offer_range_included_products_647ae97e` (`range_id`),
  KEY `offer_range_included_products_bb420c12` (`product_id`),
  CONSTRAINT `product_id_refs_id_1a75e0f42e44edc2` FOREIGN KEY (`product_id`) REFERENCES `catalogue_product` (`id`),
  CONSTRAINT `range_id_refs_id_40fb1ebce577c797` FOREIGN KEY (`range_id`) REFERENCES `offer_range` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offer_range_included_products`
--

LOCK TABLES `offer_range_included_products` WRITE;
/*!40000 ALTER TABLE `offer_range_included_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `offer_range_included_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_billingaddress`
--

DROP TABLE IF EXISTS `order_billingaddress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_billingaddress` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(64) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) NOT NULL,
  `line1` varchar(255) NOT NULL,
  `line2` varchar(255) DEFAULT NULL,
  `line3` varchar(255) DEFAULT NULL,
  `line4` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `postcode` varchar(64) NOT NULL,
  `country_id` varchar(2) NOT NULL,
  `search_text` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_billingaddress_534dd89` (`country_id`),
  CONSTRAINT `country_id_refs_iso_3166_1_a2_46dc039dbc502af1` FOREIGN KEY (`country_id`) REFERENCES `address_country` (`iso_3166_1_a2`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_billingaddress`
--

LOCK TABLES `order_billingaddress` WRITE;
/*!40000 ALTER TABLE `order_billingaddress` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_billingaddress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_communicationevent`
--

DROP TABLE IF EXISTS `order_communicationevent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_communicationevent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `event_type_id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_communicationevent_8337030b` (`order_id`),
  KEY `order_communicationevent_cb60d07f` (`event_type_id`),
  CONSTRAINT `event_type_id_refs_id_ba3124ff879d694` FOREIGN KEY (`event_type_id`) REFERENCES `customer_communicationeventtype` (`id`),
  CONSTRAINT `order_id_refs_id_7fa8c830b8eb0eba` FOREIGN KEY (`order_id`) REFERENCES `order_order` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_communicationevent`
--

LOCK TABLES `order_communicationevent` WRITE;
/*!40000 ALTER TABLE `order_communicationevent` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_communicationevent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_line`
--

DROP TABLE IF EXISTS `order_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_line` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `partner_id` int(11) DEFAULT NULL,
  `partner_name` varchar(128) NOT NULL,
  `partner_sku` varchar(128) NOT NULL,
  `title` varchar(255) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quantity` int(10) unsigned NOT NULL,
  `line_price_incl_tax` decimal(12,2) NOT NULL,
  `line_price_excl_tax` decimal(12,2) NOT NULL,
  `line_price_before_discounts_incl_tax` decimal(12,2) NOT NULL,
  `line_price_before_discounts_excl_tax` decimal(12,2) NOT NULL,
  `unit_cost_price` decimal(12,2) DEFAULT NULL,
  `unit_price_incl_tax` decimal(12,2) DEFAULT NULL,
  `unit_price_excl_tax` decimal(12,2) DEFAULT NULL,
  `unit_retail_price` decimal(12,2) DEFAULT NULL,
  `partner_line_reference` varchar(128) DEFAULT NULL,
  `partner_line_notes` longtext,
  `status` varchar(255) DEFAULT NULL,
  `est_dispatch_date` date DEFAULT NULL,
  `upc` varchar(128),
  PRIMARY KEY (`id`),
  KEY `order_line_8337030b` (`order_id`),
  KEY `order_line_76043359` (`partner_id`),
  KEY `order_line_bb420c12` (`product_id`),
  CONSTRAINT `order_id_refs_id_41b6b2c9d42195c6` FOREIGN KEY (`order_id`) REFERENCES `order_order` (`id`),
  CONSTRAINT `partner_id_refs_id_45e863e667e3d83e` FOREIGN KEY (`partner_id`) REFERENCES `partner_partner` (`id`),
  CONSTRAINT `product_id_refs_id_2650c43364803c72` FOREIGN KEY (`product_id`) REFERENCES `catalogue_product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_line`
--

LOCK TABLES `order_line` WRITE;
/*!40000 ALTER TABLE `order_line` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_line` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_lineattribute`
--

DROP TABLE IF EXISTS `order_lineattribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_lineattribute` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `line_id` int(11) NOT NULL,
  `option_id` int(11) DEFAULT NULL,
  `type` varchar(128) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_lineattribute_92b3444a` (`line_id`),
  KEY `order_lineattribute_2f3b0dc9` (`option_id`),
  CONSTRAINT `line_id_refs_id_38dee8035c8609ba` FOREIGN KEY (`line_id`) REFERENCES `order_line` (`id`),
  CONSTRAINT `option_id_refs_id_6f5636bb5d7ef970` FOREIGN KEY (`option_id`) REFERENCES `catalogue_option` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_lineattribute`
--

LOCK TABLES `order_lineattribute` WRITE;
/*!40000 ALTER TABLE `order_lineattribute` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_lineattribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_lineprice`
--

DROP TABLE IF EXISTS `order_lineprice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_lineprice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `line_id` int(11) NOT NULL,
  `quantity` int(10) unsigned NOT NULL,
  `price_incl_tax` decimal(12,2) NOT NULL,
  `price_excl_tax` decimal(12,2) NOT NULL,
  `shipping_incl_tax` decimal(12,2) NOT NULL,
  `shipping_excl_tax` decimal(12,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_lineprice_8337030b` (`order_id`),
  KEY `order_lineprice_92b3444a` (`line_id`),
  CONSTRAINT `line_id_refs_id_200dbb454e9f1385` FOREIGN KEY (`line_id`) REFERENCES `order_line` (`id`),
  CONSTRAINT `order_id_refs_id_69b3fb8dd6da2c8e` FOREIGN KEY (`order_id`) REFERENCES `order_order` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_lineprice`
--

LOCK TABLES `order_lineprice` WRITE;
/*!40000 ALTER TABLE `order_lineprice` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_lineprice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_order`
--

DROP TABLE IF EXISTS `order_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` varchar(128) NOT NULL,
  `site_id` int(11) NOT NULL,
  `basket_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `billing_address_id` int(11) DEFAULT NULL,
  `total_incl_tax` decimal(12,2) NOT NULL,
  `total_excl_tax` decimal(12,2) NOT NULL,
  `shipping_incl_tax` decimal(12,2) NOT NULL,
  `shipping_excl_tax` decimal(12,2) NOT NULL,
  `shipping_address_id` int(11) DEFAULT NULL,
  `shipping_method` varchar(128) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `date_placed` datetime NOT NULL,
  `guest_email` varchar(75),
  PRIMARY KEY (`id`),
  KEY `order_order_7c2dab66` (`number`),
  KEY `order_order_6223029` (`site_id`),
  KEY `order_order_fbfc09f1` (`user_id`),
  KEY `order_order_c624c233` (`billing_address_id`),
  KEY `order_order_20484567` (`shipping_address_id`),
  KEY `order_order_aec39660` (`date_placed`),
  CONSTRAINT `billing_address_id_refs_id_6dfa75419ae0c54d` FOREIGN KEY (`billing_address_id`) REFERENCES `order_billingaddress` (`id`),
  CONSTRAINT `shipping_address_id_refs_id_6806ac37922eb951` FOREIGN KEY (`shipping_address_id`) REFERENCES `order_shippingaddress` (`id`),
  CONSTRAINT `site_id_refs_id_431ca369672c7579` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`),
  CONSTRAINT `user_id_refs_id_5c3d57cd7cecdbde` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_order`
--

LOCK TABLES `order_order` WRITE;
/*!40000 ALTER TABLE `order_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_orderdiscount`
--

DROP TABLE IF EXISTS `order_orderdiscount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_orderdiscount` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `offer_id` int(10) unsigned DEFAULT NULL,
  `voucher_id` int(10) unsigned DEFAULT NULL,
  `voucher_code` varchar(128) DEFAULT NULL,
  `amount` decimal(12,2) NOT NULL,
  `offer_name` varchar(128),
  `frequency` int(10) unsigned,
  `category` varchar(64) NOT NULL,
  `message` longtext,
  PRIMARY KEY (`id`),
  KEY `order_orderdiscount_8337030b` (`order_id`),
  KEY `order_orderdiscount_740e861f` (`voucher_code`),
  KEY `order_orderdiscount_e25d1f01` (`offer_name`),
  CONSTRAINT `order_id_refs_id_2859e864edf6808a` FOREIGN KEY (`order_id`) REFERENCES `order_order` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_orderdiscount`
--

LOCK TABLES `order_orderdiscount` WRITE;
/*!40000 ALTER TABLE `order_orderdiscount` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_orderdiscount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_ordernote`
--

DROP TABLE IF EXISTS `order_ordernote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_ordernote` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `note_type` varchar(128) DEFAULT NULL,
  `message` longtext NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_ordernote_8337030b` (`order_id`),
  KEY `order_ordernote_fbfc09f1` (`user_id`),
  CONSTRAINT `order_id_refs_id_339c790b43539aed` FOREIGN KEY (`order_id`) REFERENCES `order_order` (`id`),
  CONSTRAINT `user_id_refs_id_6265a0c220ba9fb6` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_ordernote`
--

LOCK TABLES `order_ordernote` WRITE;
/*!40000 ALTER TABLE `order_ordernote` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_ordernote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_paymentevent`
--

DROP TABLE IF EXISTS `order_paymentevent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_paymentevent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `event_type_id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_paymentevent_8337030b` (`order_id`),
  KEY `order_paymentevent_cb60d07f` (`event_type_id`),
  CONSTRAINT `event_type_id_refs_id_4a8935f09811ffa1` FOREIGN KEY (`event_type_id`) REFERENCES `order_paymenteventtype` (`id`),
  CONSTRAINT `order_id_refs_id_7a07cc6e91bf25f2` FOREIGN KEY (`order_id`) REFERENCES `order_order` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_paymentevent`
--

LOCK TABLES `order_paymentevent` WRITE;
/*!40000 ALTER TABLE `order_paymentevent` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_paymentevent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_paymenteventquantity`
--

DROP TABLE IF EXISTS `order_paymenteventquantity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_paymenteventquantity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` int(11) NOT NULL,
  `line_id` int(11) NOT NULL,
  `quantity` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_paymenteventquantity_e9b82f95` (`event_id`),
  KEY `order_paymenteventquantity_92b3444a` (`line_id`),
  CONSTRAINT `event_id_refs_id_245047245ab5ee` FOREIGN KEY (`event_id`) REFERENCES `order_paymentevent` (`id`),
  CONSTRAINT `line_id_refs_id_7a93bc6292614f2e` FOREIGN KEY (`line_id`) REFERENCES `order_line` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_paymenteventquantity`
--

LOCK TABLES `order_paymenteventquantity` WRITE;
/*!40000 ALTER TABLE `order_paymenteventquantity` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_paymenteventquantity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_paymenteventtype`
--

DROP TABLE IF EXISTS `order_paymenteventtype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_paymenteventtype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `code` varchar(128) NOT NULL,
  `sequence_number` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_paymenteventtype`
--

LOCK TABLES `order_paymenteventtype` WRITE;
/*!40000 ALTER TABLE `order_paymenteventtype` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_paymenteventtype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_shippingaddress`
--

DROP TABLE IF EXISTS `order_shippingaddress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_shippingaddress` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(64) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) NOT NULL,
  `line1` varchar(255) NOT NULL,
  `line2` varchar(255) DEFAULT NULL,
  `line3` varchar(255) DEFAULT NULL,
  `line4` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `postcode` varchar(64) NOT NULL,
  `country_id` varchar(2) NOT NULL,
  `search_text` varchar(1000) NOT NULL,
  `phone_number` varchar(32) DEFAULT NULL,
  `notes` longtext,
  PRIMARY KEY (`id`),
  KEY `order_shippingaddress_534dd89` (`country_id`),
  CONSTRAINT `country_id_refs_iso_3166_1_a2_791be16a6ed25861` FOREIGN KEY (`country_id`) REFERENCES `address_country` (`iso_3166_1_a2`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_shippingaddress`
--

LOCK TABLES `order_shippingaddress` WRITE;
/*!40000 ALTER TABLE `order_shippingaddress` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_shippingaddress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_shippingevent`
--

DROP TABLE IF EXISTS `order_shippingevent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_shippingevent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `event_type_id` int(11) NOT NULL,
  `notes` longtext,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_shippingevent_8337030b` (`order_id`),
  KEY `order_shippingevent_cb60d07f` (`event_type_id`),
  CONSTRAINT `event_type_id_refs_id_57226223bd6239df` FOREIGN KEY (`event_type_id`) REFERENCES `order_shippingeventtype` (`id`),
  CONSTRAINT `order_id_refs_id_65a0187ef9e4abd9` FOREIGN KEY (`order_id`) REFERENCES `order_order` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_shippingevent`
--

LOCK TABLES `order_shippingevent` WRITE;
/*!40000 ALTER TABLE `order_shippingevent` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_shippingevent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_shippingeventquantity`
--

DROP TABLE IF EXISTS `order_shippingeventquantity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_shippingeventquantity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` int(11) NOT NULL,
  `line_id` int(11) NOT NULL,
  `quantity` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_shippingeventquantity_e9b82f95` (`event_id`),
  KEY `order_shippingeventquantity_92b3444a` (`line_id`),
  CONSTRAINT `event_id_refs_id_29aa204d1d104ab4` FOREIGN KEY (`event_id`) REFERENCES `order_shippingevent` (`id`),
  CONSTRAINT `line_id_refs_id_5c3a0f25bda203b3` FOREIGN KEY (`line_id`) REFERENCES `order_line` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_shippingeventquantity`
--

LOCK TABLES `order_shippingeventquantity` WRITE;
/*!40000 ALTER TABLE `order_shippingeventquantity` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_shippingeventquantity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_shippingeventtype`
--

DROP TABLE IF EXISTS `order_shippingeventtype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_shippingeventtype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `code` varchar(128) NOT NULL,
  `is_required` tinyint(1) NOT NULL,
  `sequence_number` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_shippingeventtype`
--

LOCK TABLES `order_shippingeventtype` WRITE;
/*!40000 ALTER TABLE `order_shippingeventtype` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_shippingeventtype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `partner_partner`
--

DROP TABLE IF EXISTS `partner_partner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `partner_partner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128),
  `code` varchar(128) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `partner_partner_code_6d336eee39c91508_uniq` (`code`),
  KEY `partner_partner_65da3d2c` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partner_partner`
--

LOCK TABLES `partner_partner` WRITE;
/*!40000 ALTER TABLE `partner_partner` DISABLE KEYS */;
INSERT INTO `partner_partner` VALUES (1,'The Main Partner','TMP');
/*!40000 ALTER TABLE `partner_partner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `partner_partner_users`
--

DROP TABLE IF EXISTS `partner_partner_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `partner_partner_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `partner_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `partner_partner_users_partner_id_bd29f702075850b_uniq` (`partner_id`,`user_id`),
  KEY `partner_partner_users_76043359` (`partner_id`),
  KEY `partner_partner_users_fbfc09f1` (`user_id`),
  CONSTRAINT `partner_id_refs_id_364a17a781fd89d4` FOREIGN KEY (`partner_id`) REFERENCES `partner_partner` (`id`),
  CONSTRAINT `user_id_refs_id_348f5484bed11745` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partner_partner_users`
--

LOCK TABLES `partner_partner_users` WRITE;
/*!40000 ALTER TABLE `partner_partner_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `partner_partner_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `partner_stockalert`
--

DROP TABLE IF EXISTS `partner_stockalert`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `partner_stockalert` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stockrecord_id` int(11) NOT NULL,
  `threshold` int(10) unsigned NOT NULL,
  `status` varchar(128) NOT NULL,
  `date_created` datetime NOT NULL,
  `date_closed` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `partner_abstractstockalert_c847f7ce` (`stockrecord_id`),
  CONSTRAINT `stockrecord_id_refs_id_b4acdf8626b5387` FOREIGN KEY (`stockrecord_id`) REFERENCES `partner_stockrecord` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partner_stockalert`
--

LOCK TABLES `partner_stockalert` WRITE;
/*!40000 ALTER TABLE `partner_stockalert` DISABLE KEYS */;
/*!40000 ALTER TABLE `partner_stockalert` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `partner_stockrecord`
--

DROP TABLE IF EXISTS `partner_stockrecord`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `partner_stockrecord` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `partner_id` int(11) NOT NULL,
  `partner_sku` varchar(128) NOT NULL,
  `price_currency` varchar(12) NOT NULL,
  `price_excl_tax` decimal(12,2) DEFAULT NULL,
  `price_retail` decimal(12,2) DEFAULT NULL,
  `cost_price` decimal(12,2) DEFAULT NULL,
  `num_in_stock` int(10) unsigned,
  `num_allocated` int(11) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  `low_stock_threshold` int(10) unsigned,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_id` (`product_id`),
  UNIQUE KEY `partner_stockrecord_partner_id_4faf51cd0ce15682_uniq` (`partner_id`,`partner_sku`),
  KEY `partner_stockrecord_76043359` (`partner_id`),
  KEY `partner_stockrecord_bdd0404b` (`date_updated`),
  CONSTRAINT `partner_id_refs_id_6271d43827fe0420` FOREIGN KEY (`partner_id`) REFERENCES `partner_partner` (`id`),
  CONSTRAINT `product_id_refs_id_3eac4eb59b3babbc` FOREIGN KEY (`product_id`) REFERENCES `catalogue_product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partner_stockrecord`
--

LOCK TABLES `partner_stockrecord` WRITE;
/*!40000 ALTER TABLE `partner_stockrecord` DISABLE KEYS */;
INSERT INTO `partner_stockrecord` VALUES (1,1,1,'TMP1','GBP',100.00,200.00,220.00,10,0,'2013-05-11 08:32:19','2013-05-21 10:15:37',3);
/*!40000 ALTER TABLE `partner_stockrecord` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_bankcard`
--

DROP TABLE IF EXISTS `payment_bankcard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_bankcard` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `card_type` varchar(128) NOT NULL,
  `name` varchar(255) NOT NULL,
  `number` varchar(32) NOT NULL,
  `expiry_date` date NOT NULL,
  `partner_reference` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payment_bankcard_fbfc09f1` (`user_id`),
  CONSTRAINT `user_id_refs_id_6848b6499d4140ed` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_bankcard`
--

LOCK TABLES `payment_bankcard` WRITE;
/*!40000 ALTER TABLE `payment_bankcard` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_bankcard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_source`
--

DROP TABLE IF EXISTS `payment_source`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_source` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `source_type_id` int(11) NOT NULL,
  `currency` varchar(12) NOT NULL,
  `amount_allocated` decimal(12,2) NOT NULL,
  `amount_debited` decimal(12,2) NOT NULL,
  `amount_refunded` decimal(12,2) NOT NULL,
  `reference` varchar(128) DEFAULT NULL,
  `label` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payment_source_8337030b` (`order_id`),
  KEY `payment_source_d4583c31` (`source_type_id`),
  CONSTRAINT `order_id_refs_id_211b9616ee4b5de3` FOREIGN KEY (`order_id`) REFERENCES `order_order` (`id`),
  CONSTRAINT `source_type_id_refs_id_66931ec6b872619` FOREIGN KEY (`source_type_id`) REFERENCES `payment_sourcetype` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_source`
--

LOCK TABLES `payment_source` WRITE;
/*!40000 ALTER TABLE `payment_source` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_source` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_sourcetype`
--

DROP TABLE IF EXISTS `payment_sourcetype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_sourcetype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `code` varchar(128) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `payment_sourcetype_65da3d2c` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_sourcetype`
--

LOCK TABLES `payment_sourcetype` WRITE;
/*!40000 ALTER TABLE `payment_sourcetype` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_sourcetype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_transaction`
--

DROP TABLE IF EXISTS `payment_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_transaction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `source_id` int(11) NOT NULL,
  `txn_type` varchar(128) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `reference` varchar(128) DEFAULT NULL,
  `status` varchar(128) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `payment_transaction_89f89e85` (`source_id`),
  CONSTRAINT `source_id_refs_id_4222dbbcc4118383` FOREIGN KEY (`source_id`) REFERENCES `payment_source` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_transaction`
--

LOCK TABLES `payment_transaction` WRITE;
/*!40000 ALTER TABLE `payment_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `promotions_automaticproductlist`
--

DROP TABLE IF EXISTS `promotions_automaticproductlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `promotions_automaticproductlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` longtext,
  `link_url` varchar(200) DEFAULT NULL,
  `link_text` varchar(255) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `method` varchar(128) NOT NULL,
  `num_products` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promotions_automaticproductlist`
--

LOCK TABLES `promotions_automaticproductlist` WRITE;
/*!40000 ALTER TABLE `promotions_automaticproductlist` DISABLE KEYS */;
/*!40000 ALTER TABLE `promotions_automaticproductlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `promotions_handpickedproductlist`
--

DROP TABLE IF EXISTS `promotions_handpickedproductlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `promotions_handpickedproductlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` longtext,
  `link_url` varchar(200) DEFAULT NULL,
  `link_text` varchar(255) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promotions_handpickedproductlist`
--

LOCK TABLES `promotions_handpickedproductlist` WRITE;
/*!40000 ALTER TABLE `promotions_handpickedproductlist` DISABLE KEYS */;
/*!40000 ALTER TABLE `promotions_handpickedproductlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `promotions_image`
--

DROP TABLE IF EXISTS `promotions_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `promotions_image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `link_url` varchar(200) DEFAULT NULL,
  `image` varchar(100) NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promotions_image`
--

LOCK TABLES `promotions_image` WRITE;
/*!40000 ALTER TABLE `promotions_image` DISABLE KEYS */;
/*!40000 ALTER TABLE `promotions_image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `promotions_keywordpromotion`
--

DROP TABLE IF EXISTS `promotions_keywordpromotion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `promotions_keywordpromotion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content_type_id` int(11) NOT NULL,
  `object_id` int(10) unsigned NOT NULL,
  `position` varchar(100) NOT NULL,
  `display_order` int(10) unsigned NOT NULL,
  `clicks` int(10) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `keyword` varchar(200) NOT NULL,
  `filter` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `promotions_keywordpromotion_e4470c6e` (`content_type_id`),
  CONSTRAINT `content_type_id_refs_id_7342f7064b29ce5e` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promotions_keywordpromotion`
--

LOCK TABLES `promotions_keywordpromotion` WRITE;
/*!40000 ALTER TABLE `promotions_keywordpromotion` DISABLE KEYS */;
/*!40000 ALTER TABLE `promotions_keywordpromotion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `promotions_multiimage`
--

DROP TABLE IF EXISTS `promotions_multiimage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `promotions_multiimage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promotions_multiimage`
--

LOCK TABLES `promotions_multiimage` WRITE;
/*!40000 ALTER TABLE `promotions_multiimage` DISABLE KEYS */;
/*!40000 ALTER TABLE `promotions_multiimage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `promotions_multiimage_images`
--

DROP TABLE IF EXISTS `promotions_multiimage_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `promotions_multiimage_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `multiimage_id` int(11) NOT NULL,
  `image_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `promotions_multiimage_image_multiimage_id_69609fd2c3956508_uniq` (`multiimage_id`,`image_id`),
  KEY `promotions_multiimage_images_52d9522c` (`multiimage_id`),
  KEY `promotions_multiimage_images_6682136` (`image_id`),
  CONSTRAINT `image_id_refs_id_4ee9d77f8c30676b` FOREIGN KEY (`image_id`) REFERENCES `promotions_image` (`id`),
  CONSTRAINT `multiimage_id_refs_id_294efa303dd41277` FOREIGN KEY (`multiimage_id`) REFERENCES `promotions_multiimage` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promotions_multiimage_images`
--

LOCK TABLES `promotions_multiimage_images` WRITE;
/*!40000 ALTER TABLE `promotions_multiimage_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `promotions_multiimage_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `promotions_orderedproduct`
--

DROP TABLE IF EXISTS `promotions_orderedproduct`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `promotions_orderedproduct` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `list_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `display_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `promotions_orderedproduct_863177d8` (`list_id`),
  KEY `promotions_orderedproduct_bb420c12` (`product_id`),
  CONSTRAINT `list_id_refs_id_3101fc951ed901a` FOREIGN KEY (`list_id`) REFERENCES `promotions_handpickedproductlist` (`id`),
  CONSTRAINT `product_id_refs_id_3efa567c90787ee5` FOREIGN KEY (`product_id`) REFERENCES `catalogue_product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promotions_orderedproduct`
--

LOCK TABLES `promotions_orderedproduct` WRITE;
/*!40000 ALTER TABLE `promotions_orderedproduct` DISABLE KEYS */;
/*!40000 ALTER TABLE `promotions_orderedproduct` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `promotions_orderedproductlist`
--

DROP TABLE IF EXISTS `promotions_orderedproductlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `promotions_orderedproductlist` (
  `handpickedproductlist_ptr_id` int(11) NOT NULL,
  `tabbed_block_id` int(11) NOT NULL,
  `display_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`handpickedproductlist_ptr_id`),
  KEY `promotions_orderedproductlist_29b8ba0c` (`tabbed_block_id`),
  CONSTRAINT `handpickedproductlist_ptr_id_refs_id_7c1f09cc80a5da72` FOREIGN KEY (`handpickedproductlist_ptr_id`) REFERENCES `promotions_handpickedproductlist` (`id`),
  CONSTRAINT `tabbed_block_id_refs_id_5ab6761ee90f72b3` FOREIGN KEY (`tabbed_block_id`) REFERENCES `promotions_tabbedblock` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promotions_orderedproductlist`
--

LOCK TABLES `promotions_orderedproductlist` WRITE;
/*!40000 ALTER TABLE `promotions_orderedproductlist` DISABLE KEYS */;
/*!40000 ALTER TABLE `promotions_orderedproductlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `promotions_pagepromotion`
--

DROP TABLE IF EXISTS `promotions_pagepromotion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `promotions_pagepromotion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content_type_id` int(11) NOT NULL,
  `object_id` int(10) unsigned NOT NULL,
  `position` varchar(100) NOT NULL,
  `display_order` int(10) unsigned NOT NULL,
  `clicks` int(10) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `page_url` varchar(128) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `promotions_pagepromotion_e4470c6e` (`content_type_id`),
  KEY `promotions_pagepromotion_53331fd0` (`page_url`),
  CONSTRAINT `content_type_id_refs_id_14e55bbdcee72fb1` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promotions_pagepromotion`
--

LOCK TABLES `promotions_pagepromotion` WRITE;
/*!40000 ALTER TABLE `promotions_pagepromotion` DISABLE KEYS */;
/*!40000 ALTER TABLE `promotions_pagepromotion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `promotions_rawhtml`
--

DROP TABLE IF EXISTS `promotions_rawhtml`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `promotions_rawhtml` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `display_type` varchar(128) DEFAULT NULL,
  `body` longtext NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promotions_rawhtml`
--

LOCK TABLES `promotions_rawhtml` WRITE;
/*!40000 ALTER TABLE `promotions_rawhtml` DISABLE KEYS */;
/*!40000 ALTER TABLE `promotions_rawhtml` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `promotions_singleproduct`
--

DROP TABLE IF EXISTS `promotions_singleproduct`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `promotions_singleproduct` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `product_id` int(11) NOT NULL,
  `description` longtext,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `promotions_singleproduct_bb420c12` (`product_id`),
  CONSTRAINT `product_id_refs_id_6c05b310a771ddb` FOREIGN KEY (`product_id`) REFERENCES `catalogue_product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promotions_singleproduct`
--

LOCK TABLES `promotions_singleproduct` WRITE;
/*!40000 ALTER TABLE `promotions_singleproduct` DISABLE KEYS */;
/*!40000 ALTER TABLE `promotions_singleproduct` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `promotions_tabbedblock`
--

DROP TABLE IF EXISTS `promotions_tabbedblock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `promotions_tabbedblock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promotions_tabbedblock`
--

LOCK TABLES `promotions_tabbedblock` WRITE;
/*!40000 ALTER TABLE `promotions_tabbedblock` DISABLE KEYS */;
/*!40000 ALTER TABLE `promotions_tabbedblock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ranges_rangeproductfileupload`
--

DROP TABLE IF EXISTS `ranges_rangeproductfileupload`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ranges_rangeproductfileupload` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `range_id` int(11) NOT NULL,
  `filepath` varchar(255) NOT NULL,
  `size` int(10) unsigned NOT NULL,
  `uploaded_by_id` int(11) NOT NULL,
  `date_uploaded` datetime NOT NULL,
  `status` varchar(32) NOT NULL,
  `error_message` varchar(255) DEFAULT NULL,
  `date_processed` datetime DEFAULT NULL,
  `num_new_skus` int(10) unsigned DEFAULT NULL,
  `num_unknown_skus` int(10) unsigned DEFAULT NULL,
  `num_duplicate_skus` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ranges_rangeproductfileupload_647ae97e` (`range_id`),
  KEY `ranges_rangeproductfileupload_e43a31e7` (`uploaded_by_id`),
  CONSTRAINT `range_id_refs_id_2cefb4c8ec6b74d5` FOREIGN KEY (`range_id`) REFERENCES `offer_range` (`id`),
  CONSTRAINT `uploaded_by_id_refs_id_353b6f5df0eabd0b` FOREIGN KEY (`uploaded_by_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ranges_rangeproductfileupload`
--

LOCK TABLES `ranges_rangeproductfileupload` WRITE;
/*!40000 ALTER TABLE `ranges_rangeproductfileupload` DISABLE KEYS */;
/*!40000 ALTER TABLE `ranges_rangeproductfileupload` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reviews_productreview`
--

DROP TABLE IF EXISTS `reviews_productreview`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reviews_productreview` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) DEFAULT NULL,
  `score` smallint(6) NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` longtext NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(75) DEFAULT NULL,
  `homepage` varchar(200) DEFAULT NULL,
  `status` smallint(6) NOT NULL,
  `total_votes` int(11) NOT NULL,
  `delta_votes` int(11) NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_id` (`product_id`,`user_id`),
  KEY `reviews_productreview_bb420c12` (`product_id`),
  KEY `reviews_productreview_fbfc09f1` (`user_id`),
  KEY `reviews_productreview_5005a464` (`delta_votes`),
  CONSTRAINT `user_id_refs_id_813fe4aa` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviews_productreview`
--

LOCK TABLES `reviews_productreview` WRITE;
/*!40000 ALTER TABLE `reviews_productreview` DISABLE KEYS */;
/*!40000 ALTER TABLE `reviews_productreview` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reviews_vote`
--

DROP TABLE IF EXISTS `reviews_vote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reviews_vote` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `review_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `delta` smallint(6) NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`review_id`),
  KEY `reviews_vote_9038cf0e` (`review_id`),
  KEY `reviews_vote_fbfc09f1` (`user_id`),
  CONSTRAINT `review_id_refs_id_e549118d` FOREIGN KEY (`review_id`) REFERENCES `reviews_productreview` (`id`),
  CONSTRAINT `user_id_refs_id_96cd14ee` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviews_vote`
--

LOCK TABLES `reviews_vote` WRITE;
/*!40000 ALTER TABLE `reviews_vote` DISABLE KEYS */;
/*!40000 ALTER TABLE `reviews_vote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipping_orderanditemcharges`
--

DROP TABLE IF EXISTS `shipping_orderanditemcharges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shipping_orderanditemcharges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(128) NOT NULL,
  `name` varchar(128) NOT NULL,
  `description` longtext NOT NULL,
  `price_per_order` decimal(12,2) NOT NULL,
  `price_per_item` decimal(12,2) NOT NULL,
  `free_shipping_threshold` decimal(12,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  UNIQUE KEY `shipping_orderanditemcharges_name_13c2642f48875fce_uniq` (`name`),
  KEY `shipping_orderanditemcharges_65da3d2c` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipping_orderanditemcharges`
--

LOCK TABLES `shipping_orderanditemcharges` WRITE;
/*!40000 ALTER TABLE `shipping_orderanditemcharges` DISABLE KEYS */;
/*!40000 ALTER TABLE `shipping_orderanditemcharges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipping_orderanditemcharges_countries`
--

DROP TABLE IF EXISTS `shipping_orderanditemcharges_countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shipping_orderanditemcharges_countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderanditemcharges_id` int(11) NOT NULL,
  `country_id` varchar(2) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `shipping_orderandi_orderanditemcharges_id_3f857cb2380dca46_uniq` (`orderanditemcharges_id`,`country_id`),
  KEY `shipping_orderanditemcharges_countries_334cfb26` (`orderanditemcharges_id`),
  KEY `shipping_orderanditemcharges_countries_534dd89` (`country_id`),
  CONSTRAINT `country_id_refs_iso_3166_1_a2_d2648ff2909114c` FOREIGN KEY (`country_id`) REFERENCES `address_country` (`iso_3166_1_a2`),
  CONSTRAINT `orderanditemcharges_id_refs_id_8c2f7a349dbc55a` FOREIGN KEY (`orderanditemcharges_id`) REFERENCES `shipping_orderanditemcharges` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipping_orderanditemcharges_countries`
--

LOCK TABLES `shipping_orderanditemcharges_countries` WRITE;
/*!40000 ALTER TABLE `shipping_orderanditemcharges_countries` DISABLE KEYS */;
/*!40000 ALTER TABLE `shipping_orderanditemcharges_countries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipping_weightband`
--

DROP TABLE IF EXISTS `shipping_weightband`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shipping_weightband` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `upper_limit` double NOT NULL,
  `charge` decimal(12,2) NOT NULL,
  `method_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shipping_weightband_3dacb16f` (`method_id`),
  CONSTRAINT `method_id_refs_id_2806784f5ba83eea` FOREIGN KEY (`method_id`) REFERENCES `shipping_weightbased` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipping_weightband`
--

LOCK TABLES `shipping_weightband` WRITE;
/*!40000 ALTER TABLE `shipping_weightband` DISABLE KEYS */;
/*!40000 ALTER TABLE `shipping_weightband` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipping_weightbased`
--

DROP TABLE IF EXISTS `shipping_weightbased`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shipping_weightbased` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(128) NOT NULL,
  `name` varchar(128) NOT NULL,
  `description` longtext NOT NULL,
  `upper_charge` decimal(12,2) DEFAULT NULL,
  `default_weight` decimal(12,2) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipping_weightbased`
--

LOCK TABLES `shipping_weightbased` WRITE;
/*!40000 ALTER TABLE `shipping_weightbased` DISABLE KEYS */;
/*!40000 ALTER TABLE `shipping_weightbased` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipping_weightbased_countries`
--

DROP TABLE IF EXISTS `shipping_weightbased_countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shipping_weightbased_countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weightbased_id` int(11) NOT NULL,
  `country_id` varchar(2) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `shipping_weightbased_count_weightbased_id_2d48b23bd516c826_uniq` (`weightbased_id`,`country_id`),
  KEY `shipping_weightbased_countries_2b8a5aca` (`weightbased_id`),
  KEY `shipping_weightbased_countries_534dd89` (`country_id`),
  CONSTRAINT `country_id_refs_iso_3166_1_a2_3df0718a331f1b98` FOREIGN KEY (`country_id`) REFERENCES `address_country` (`iso_3166_1_a2`),
  CONSTRAINT `weightbased_id_refs_id_3ed50866582640e2` FOREIGN KEY (`weightbased_id`) REFERENCES `shipping_weightbased` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipping_weightbased_countries`
--

LOCK TABLES `shipping_weightbased_countries` WRITE;
/*!40000 ALTER TABLE `shipping_weightbased_countries` DISABLE KEYS */;
/*!40000 ALTER TABLE `shipping_weightbased_countries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `south_migrationhistory`
--

DROP TABLE IF EXISTS `south_migrationhistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `south_migrationhistory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_name` varchar(255) NOT NULL,
  `migration` varchar(255) NOT NULL,
  `applied` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `south_migrationhistory`
--

LOCK TABLES `south_migrationhistory` WRITE;
/*!40000 ALTER TABLE `south_migrationhistory` DISABLE KEYS */;
INSERT INTO `south_migrationhistory` VALUES (1,'menu','0001_initial','2013-05-08 14:24:29'),(2,'dashboard','0001_initial','2013-05-08 14:24:29'),(3,'dashboard','0002_auto__add_field_dashboardpreferences_dashboard_id','2013-05-08 14:24:29'),(4,'dashboard','0003_auto__add_unique_dashboardpreferences_dashboard_id_user','2013-05-08 14:24:30'),(5,'accounts','0001_initial','2013-05-08 14:24:32'),(6,'customer','0001_initial','2013-05-08 14:24:32'),(7,'catalogue','0001_initial','2013-05-08 14:24:37'),(8,'analytics','0001_initial','2013-05-08 14:24:38'),(9,'partner','0001_initial','2013-05-08 14:24:40'),(10,'address','0001_initial','2013-05-08 14:24:41'),(11,'order','0001_initial','2013-05-08 14:24:45'),(12,'order','0002_auto__add_field_order_guest_email','2013-05-08 14:24:45'),(13,'order','0003_auto__del_field_ordernote_date__add_field_ordernote_date_created__add_','2013-05-08 14:24:45'),(14,'order','0004_auto__add_field_line_upc','2013-05-08 14:24:46'),(15,'order','0005_auto__add_field_orderdiscount_offer_name','2013-05-08 14:24:46'),(16,'order','0006_update_offer_name_field','2013-05-08 14:24:46'),(17,'order','0007_auto__add_field_orderdiscount_frequency','2013-05-08 14:24:46'),(18,'order','0008_auto__add_field_orderdiscount_category','2013-05-08 14:24:47'),(19,'order','0009_auto__add_field_orderdiscount_message','2013-05-08 14:24:47'),(20,'checkout','0001_initial','2013-05-08 14:24:47'),(21,'shipping','0001_initial','2013-05-08 14:24:48'),(22,'shipping','0002_auto__del_orderanditemlevelchargemethod__add_orderanditemcharges__add_','2013-05-08 14:24:48'),(23,'shipping','0003_auto__add_weightbased__chg_field_orderanditemcharges_code__add_unique_','2013-05-08 14:24:48'),(24,'shipping','0004_auto__add_field_weightbased_default_weight','2013-05-08 14:24:48'),(25,'shipping','0005_auto','2013-05-08 14:24:49'),(26,'offer','0001_initial','2013-05-08 14:24:51'),(27,'voucher','0001_initial','2013-05-08 14:24:52'),(28,'basket','0001_initial','2013-05-08 14:24:53'),(29,'basket','0002_auto__add_field_line_price_incl_tax','2013-05-08 14:24:53'),(30,'basket','0003_auto__add_field_line_price_excl_tax','2013-05-08 14:24:53'),(31,'payment','0001_initial','2013-05-08 14:24:54'),(32,'offer','0002_auto__add_unique_conditionaloffer_name','2013-05-08 14:24:55'),(33,'offer','0003_auto__add_field_conditionaloffer_num_orders','2013-05-08 14:24:56'),(34,'offer','0004_auto__add_field_conditionaloffer_slug','2013-05-08 14:24:56'),(35,'offer','0005_auto__add_field_range_date_created','2013-05-08 14:24:56'),(36,'offer','0006_auto__add_field_conditionaloffer_max_applications','2013-05-08 14:24:56'),(37,'offer','0007_auto__add_field_conditionaloffer_max_global_applications','2013-05-08 14:24:56'),(38,'offer','0008_auto__add_field_conditionaloffer_num_applications','2013-05-08 14:24:56'),(39,'offer','0009_auto__del_field_conditionaloffer_max_applications__add_field_condition','2013-05-08 14:24:57'),(40,'offer','0010_auto__add_field_conditionaloffer_max_user_applications','2013-05-08 14:24:57'),(41,'offer','0011_auto__add_field_range_proxy_class','2013-05-08 14:24:57'),(42,'offer','0012_auto__add_field_condition_proxy_class__chg_field_condition_range__chg_','2013-05-08 14:24:57'),(43,'offer','0013_auto__add_unique_range_proxy_class','2013-05-08 14:24:57'),(44,'offer','0014_consolidate_offer_changes','2013-05-08 14:24:58'),(45,'offer','0015_auto__add_field_conditionaloffer_max_discount','2013-05-08 14:24:58'),(46,'offer','0016_auto__add_field_conditionaloffer_status','2013-05-08 14:24:58'),(47,'offer','0017_auto__chg_field_conditionaloffer_end_date__chg_field_conditionaloffer_','2013-05-08 14:24:58'),(48,'offer','0018_auto__del_field_conditionaloffer_end_date__del_field_conditionaloffer_','2013-05-08 14:24:59'),(49,'offer','0019_auto__del_shippingbenefit__add_field_benefit_proxy_class__chg_field_be','2013-05-08 14:24:59'),(50,'address','0002_auto__chg_field_useraddress_postcode','2013-05-08 14:25:00'),(51,'partner','0002_auto__add_stockalert__add_abstractstockalert__add_field_stockrecord_lo','2013-05-08 14:25:00'),(52,'partner','0003_auto__add_unique_stockrecord_partner_partner_sku','2013-05-08 14:25:00'),(53,'partner','0004_auto__add_field_partner_code','2013-05-08 14:25:01'),(54,'partner','0005_populate_slugs','2013-05-08 14:25:01'),(55,'partner','0006_auto__add_unique_partner_code','2013-05-08 14:25:01'),(56,'partner','0007_auto__chg_field_partner_name__del_unique_partner_name','2013-05-08 14:25:01'),(57,'partner','0008_auto__del_abstractstockalert__del_field_stockalert_abstractstockalert_','2013-05-08 14:25:01'),(58,'catalogue','0002_auto__add_field_product_status__add_field_category_description__add_fi','2013-05-08 14:25:04'),(59,'catalogue','0003_auto__add_unique_product_upc__chg_field_productcontributor_role','2013-05-08 14:25:05'),(60,'catalogue','0004_auto__chg_field_productattributevalue_value_boolean','2013-05-08 14:25:06'),(61,'catalogue','0005_auto__chg_field_productattributevalue_value_boolean__add_field_product','2013-05-08 14:25:06'),(62,'catalogue','0006_auto__add_field_product_is_discountable','2013-05-08 14:25:07'),(63,'catalogue','0007_auto__add_field_productclass_requires_shipping__add_field_productclass','2013-05-08 14:25:07'),(64,'catalogue','0008_auto__add_unique_option_code','2013-05-08 14:25:08'),(65,'catalogue','0009_auto__add_field_product_rating','2013-05-08 14:25:08'),(66,'catalogue','0010_call_update_product_ratings','2013-05-08 14:25:09'),(67,'ranges','0001_initial','2013-05-08 14:25:11'),(68,'promotions','0001_initial','2013-05-08 14:25:15'),(69,'customer','0002_auto__add_notification','2013-05-08 14:25:16'),(70,'customer','0003_auto__add_productalert','2013-05-08 14:25:18'),(71,'customer','0004_auto__chg_field_communicationeventtype_email_subject_template','2013-05-08 14:25:19'),(72,'catalogue','0011_auto','2013-05-21 10:08:00');
/*!40000 ALTER TABLE `south_migrationhistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `thumbnail_kvstore`
--

DROP TABLE IF EXISTS `thumbnail_kvstore`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `thumbnail_kvstore` (
  `key` varchar(200) NOT NULL,
  `value` longtext NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `thumbnail_kvstore`
--

LOCK TABLES `thumbnail_kvstore` WRITE;
/*!40000 ALTER TABLE `thumbnail_kvstore` DISABLE KEYS */;
INSERT INTO `thumbnail_kvstore` VALUES ('sorl-thumbnail||image||630417cf4de05987b5f3d7a6deeda4f4','{\"storage\": \"django.core.files.storage.FileSystemStorage\", \"name\": \"gallery/item_2.gif\", \"size\": [41, 53]}'),('sorl-thumbnail||image||64ee296768a18db37eca03d8e3a9e6b1','{\"storage\": \"django.core.files.storage.FileSystemStorage\", \"name\": \"gallery/portrait.gif\", \"size\": [38, 52]}'),('sorl-thumbnail||image||6d4263444451fe6bf648f4b55a03090a','{\"storage\": \"django.core.files.storage.FileSystemStorage\", \"name\": \"cache/4b/c6/4bc63497628db37a2f491da28a10b41d.jpg\", \"size\": [7, 10]}'),('sorl-thumbnail||image||7289c05130165fa454d8ac0ab2ae595e','{\"storage\": \"django.core.files.storage.FileSystemStorage\", \"name\": \"cache/fb/d8/fbd859afa16fa5c544d0b0ec00b7817d.jpg\", \"size\": [25, 32]}'),('sorl-thumbnail||image||833a367243221efc51ad84c468cafe6c','{\"storage\": \"django.core.files.storage.FileSystemStorage\", \"name\": \"gallery/item_1.gif\", \"size\": [41, 53]}'),('sorl-thumbnail||image||9d33925d217de903899ae713a2bb6d12','{\"storage\": \"django.core.files.storage.FileSystemStorage\", \"name\": \"gallery/landscape.gif\", \"size\": [52, 37]}'),('sorl-thumbnail||image||a3435871ac265ac2fce7fe4cd114b57e','{\"storage\": \"django.core.files.storage.FileSystemStorage\", \"name\": \"cache/61/1f/611f5ac8b3f71b701ac16ca4c1f3d4d5.jpg\", \"size\": [70, 67]}'),('sorl-thumbnail||image||b0e429f9998c8e822b6c57e3675b2542','{\"storage\": \"django.core.files.storage.FileSystemStorage\", \"name\": \"cache/6c/cb/6ccb4bc160e18990c66efc0e8cd41d91.jpg\", \"size\": [25, 32]}'),('sorl-thumbnail||image||b65a32c3ed9a4e151b8f02368d7d9ee0','{\"storage\": \"django.core.files.storage.FileSystemStorage\", \"name\": \"images/products/2013/05/lGCONljtbA.jpg\", \"size\": [600, 571]}'),('sorl-thumbnail||image||cbcbaf5ae250db7ed4d6d80cb24adfc3','{\"storage\": \"django.core.files.storage.FileSystemStorage\", \"name\": \"cache/18/4e/184eb7f5a7f769b7d3e7796e312a2fa2.jpg\", \"size\": [32, 23]}'),('sorl-thumbnail||image||dfa4b3bf731b37ae4fcea98f0b0be876','{\"storage\": \"django.core.files.storage.FileSystemStorage\", \"name\": \"cache/4e/f2/4ef2381fad2d171effd4f8ce9db0a31a.jpg\", \"size\": [23, 32]}'),('sorl-thumbnail||thumbnails||630417cf4de05987b5f3d7a6deeda4f4','[\"7289c05130165fa454d8ac0ab2ae595e\"]'),('sorl-thumbnail||thumbnails||64ee296768a18db37eca03d8e3a9e6b1','[\"dfa4b3bf731b37ae4fcea98f0b0be876\", \"6d4263444451fe6bf648f4b55a03090a\"]'),('sorl-thumbnail||thumbnails||833a367243221efc51ad84c468cafe6c','[\"b0e429f9998c8e822b6c57e3675b2542\"]'),('sorl-thumbnail||thumbnails||9d33925d217de903899ae713a2bb6d12','[\"cbcbaf5ae250db7ed4d6d80cb24adfc3\"]'),('sorl-thumbnail||thumbnails||b65a32c3ed9a4e151b8f02368d7d9ee0','[\"a3435871ac265ac2fce7fe4cd114b57e\"]');
/*!40000 ALTER TABLE `thumbnail_kvstore` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `voucher_voucher`
--

DROP TABLE IF EXISTS `voucher_voucher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `voucher_voucher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `code` varchar(128) NOT NULL,
  `usage` varchar(128) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `num_basket_additions` int(10) unsigned NOT NULL,
  `num_orders` int(10) unsigned NOT NULL,
  `total_discount` decimal(12,2) NOT NULL,
  `date_created` date NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voucher_voucher`
--

LOCK TABLES `voucher_voucher` WRITE;
/*!40000 ALTER TABLE `voucher_voucher` DISABLE KEYS */;
/*!40000 ALTER TABLE `voucher_voucher` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `voucher_voucher_offers`
--

DROP TABLE IF EXISTS `voucher_voucher_offers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `voucher_voucher_offers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `voucher_id` int(11) NOT NULL,
  `conditionaloffer_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `voucher_voucher_offers_voucher_id_7a0c4a351389083e_uniq` (`voucher_id`,`conditionaloffer_id`),
  KEY `voucher_voucher_offers_7a302bdb` (`voucher_id`),
  KEY `voucher_voucher_offers_aabc43b6` (`conditionaloffer_id`),
  CONSTRAINT `conditionaloffer_id_refs_id_4e201b2f3632d1fd` FOREIGN KEY (`conditionaloffer_id`) REFERENCES `offer_conditionaloffer` (`id`),
  CONSTRAINT `voucher_id_refs_id_69332a6e2417707e` FOREIGN KEY (`voucher_id`) REFERENCES `voucher_voucher` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voucher_voucher_offers`
--

LOCK TABLES `voucher_voucher_offers` WRITE;
/*!40000 ALTER TABLE `voucher_voucher_offers` DISABLE KEYS */;
/*!40000 ALTER TABLE `voucher_voucher_offers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `voucher_voucherapplication`
--

DROP TABLE IF EXISTS `voucher_voucherapplication`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `voucher_voucherapplication` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `voucher_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `order_id` int(11) NOT NULL,
  `date_created` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `voucher_voucherapplication_7a302bdb` (`voucher_id`),
  KEY `voucher_voucherapplication_fbfc09f1` (`user_id`),
  KEY `voucher_voucherapplication_8337030b` (`order_id`),
  CONSTRAINT `order_id_refs_id_1aa2a733608e4b3a` FOREIGN KEY (`order_id`) REFERENCES `order_order` (`id`),
  CONSTRAINT `user_id_refs_id_71de8958324b3d23` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `voucher_id_refs_id_642bd10988ef0ff6` FOREIGN KEY (`voucher_id`) REFERENCES `voucher_voucher` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voucher_voucherapplication`
--

LOCK TABLES `voucher_voucherapplication` WRITE;
/*!40000 ALTER TABLE `voucher_voucherapplication` DISABLE KEYS */;
/*!40000 ALTER TABLE `voucher_voucherapplication` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-05-22  8:39:29
